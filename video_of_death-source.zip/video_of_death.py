from __future__ import annotations
import sys
import os
import tempfile

# ---------------------------------------------------------------------------
# Locate ffmpeg/ffplay/ffprobe — bundled executables take priority over PATH.
# When running from PyInstaller the executables live in sys._MEIPASS.
# When running from source they should be in the same folder as this script.
# ---------------------------------------------------------------------------
def _find_ff(name):
    exe = name + (".exe" if sys.platform == "win32" else "")
    # 1. PyInstaller bundle
    if hasattr(sys, "_MEIPASS"):
        p = os.path.join(sys._MEIPASS, exe)
        if os.path.isfile(p): return p
    # 2. Same directory as the script / frozen executable
    base = os.path.dirname(sys.executable if getattr(sys, "frozen", False)
                           else os.path.abspath(__file__))
    p = os.path.join(base, exe)
    if os.path.isfile(p): return p
    # 3. Fall back to PATH
    return name

FF_MPEG  = _find_ff("ffmpeg")
FF_PLAY  = _find_ff("ffplay")
FF_PROBE = _find_ff("ffprobe")

# Persistent folder for offline-rendered audio fade WAVs.
# Wiped on every app start so a fresh process never plays a stale render
# from a previous session (which could be the wrong length / wrong fade
# duration if rendered with an older version of the render code).
_RENDER_DIR=os.path.join(tempfile.gettempdir(),"vod_audio_render")
try:
    if os.path.isdir(_RENDER_DIR):
        for _f in os.listdir(_RENDER_DIR):
            _p=os.path.join(_RENDER_DIR,_f)
            try:
                if os.path.isfile(_p): os.remove(_p)
            except Exception: pass
except Exception: pass
os.makedirs(_RENDER_DIR,exist_ok=True)

def _render_path(clip_id):
    """Return the path for a clip's pre-rendered fade MP3."""
    import hashlib
    h=hashlib.md5(clip_id.encode()).hexdigest()[:16]
    return os.path.join(_RENDER_DIR,f"clip_{h}.mp3")

def _render_exists(clip_id):
    return _render_path_for_existing(clip_id) is not None

def _render_fade_clip(clip, log_cb=None):
    """Offline-render a clip with afade baked in, returning the output path
    or None if no fades / render fails. Optional log_cb(str) receives stderr
    on failure for surfacing in the UI.

    Mirrors the afade filter used at export time so what the user hears
    during timeline playback matches what they get on export. We use
    output-side -ss (after -i) for sample-accurate trimming so the fade
    timestamps land exactly where the export pipeline puts them."""
    fi=float(getattr(clip,'fade_in',0.0) or 0.0)
    fo=float(getattr(clip,'fade_out',0.0) or 0.0)
    if fi<=0 and fo<=0:
        if log_cb: log_cb("No fade values set on clip.")
        return None
    src_in=float(getattr(clip,'source_in',0.0) or 0.0)
    dur=float(getattr(clip,'duration_on_timeline',0.0) or 0.0)
    if dur<=0:
        if log_cb: log_cb(f"Clip duration_on_timeline={dur} (must be > 0).")
        return None
    if not os.path.isfile(str(clip.path)):
        if log_cb: log_cb(f"Source file not found: {clip.path}")
        return None
    # Render to WAV: universally supported, no encoder dependency, sample-accurate.
    out_path=_render_path(clip.id)
    if out_path.endswith(".mp3"): out_path=out_path[:-4]+".wav"
    af=[]
    if fi>0: af.append(f"afade=t=in:st=0:d={fi:.3f}")
    if fo>0:
        fade_st=max(0.0,dur-fo)
        af.append(f"afade=t=out:st={fade_st:.3f}:d={fo:.3f}")
    # Input-side -ss with -accurate_seek = exactly what the export pipeline uses
    # (see export filter graph). This guarantees the rendered WAV's t=0 maps to
    # the source's source_in sample, so afade timestamps line up with playback offsets.
    # We *don't* use output-side seek: on some inputs ffmpeg ignores -ss after -i
    # combined with -af, leaving the full source in the output and making fade-out
    # land early relative to expected duration.
    cmd=[FF_MPEG,"-y","-loglevel","error",
         "-accurate_seek","-ss",f"{src_in:.6f}","-t",f"{dur:.6f}",
         "-i",str(clip.path),
         "-vn","-af",",".join(af),
         "-ar","44100","-ac","2",
         "-c:a","pcm_s16le",
         out_path]
    try:
        r=subprocess.run(cmd,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,
                         timeout=120,**_no_window())
        if r.returncode==0 and os.path.isfile(out_path) and os.path.getsize(out_path)>1024:
            # Verify rendered duration matches expected — catches cases where
            # the trim was ignored (would cause fades to land at wrong times).
            try:
                pr=subprocess.run([FF_PROBE,"-v","error","-show_entries","format=duration",
                                   "-of","default=noprint_wrappers=1:nokey=1",out_path],
                                  stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,
                                  timeout=10,**_no_window())
                rendered_dur=float(pr.stdout.decode().strip() or "0")
                if abs(rendered_dur-dur)>0.5:
                    if log_cb: log_cb(f"Rendered duration {rendered_dur:.2f}s does not match "
                                      f"expected {dur:.2f}s — fade timing would be wrong. "
                                      f"Source seek likely failed.\nCommand: {' '.join(cmd)}")
                    try: os.remove(out_path)
                    except Exception: pass
                    return None
                print(f"[FADE] rendered {os.path.basename(out_path)} dur={rendered_dur:.3f}s "
                      f"(expected {dur:.3f}s) fi={fi:.2f} fo={fo:.2f} src_in={src_in:.3f}",flush=True)
            except Exception:
                pass  # ffprobe missing or failed — accept the file
            return out_path
        err=(r.stderr or b"").decode("utf-8","replace").strip()
        if log_cb: log_cb(f"ffmpeg exit {r.returncode}\n{err[:1000]}\nCommand: {' '.join(cmd)}")
    except FileNotFoundError:
        if log_cb: log_cb(f"ffmpeg not found at: {FF_MPEG}")
    except Exception as e:
        if log_cb: log_cb(f"Render exception: {e}")
    try:
        if os.path.isfile(out_path): os.remove(out_path)
    except Exception: pass
    return None

def _render_path_for_existing(clip_id):
    """Return whichever rendered file actually exists on disk (.wav or legacy .mp3)."""
    base=_render_path(clip_id)
    wav=base[:-4]+".wav" if base.endswith(".mp3") else base+".wav"
    if os.path.isfile(wav): return wav
    if os.path.isfile(base): return base
    return None

def _invalidate_render(clip_id):
    """Delete cached fade renders for a clip (both .wav and legacy .mp3)."""
    base=_render_path(clip_id)
    for p in (base, base[:-4]+".wav" if base.endswith(".mp3") else base+".wav"):
        try:
            if os.path.isfile(p): os.remove(p)
        except Exception: pass



# On Windows (including PyInstaller builds) every subprocess.Popen/run call
# creates a brief console flash. We suppress it using STARTF_USESHOWWINDOW +
# SW_HIDE via STARTUPINFO — this hides the window without using
# CREATE_NO_WINDOW (0x08000000), which breaks audio device access on Windows.
def _no_window():
    if sys.platform != "win32": return {}
    si=subprocess.STARTUPINFO()
    si.dwFlags|=subprocess.STARTF_USESHOWWINDOW
    si.wShowWindow=0   # SW_HIDE
    return {"startupinfo": si}
import time
import math
import subprocess
import json
from pathlib import Path
from typing import Optional, List, Dict, Any, Tuple
from dataclasses import dataclass, field
from enum import Enum

# PyQt6 Imports
from PyQt6.QtCore import Qt, QTimer, QThread, pyqtSignal, QPointF, QRectF, QSize, QObject, QSettings
import copy, threading
from PyQt6.QtGui import QColor, QFont, QPainter, QPixmap, QPen, QBrush, QImage, QAction, QPalette, QIcon
from PyQt6.QtWidgets import (
    QApplication, QWidget, QSplashScreen, QMainWindow, QVBoxLayout, 
    QHBoxLayout, QSplitter, QDockWidget, QLabel, QPushButton, 
    QSlider, QSpinBox, QComboBox, QListWidget, 
    QListWidgetItem, QScrollArea, QFrame, QSizePolicy, QFileDialog,
    QMessageBox, QToolBar, QMenu, QMenuBar, QStatusBar,
    QGraphicsView, QGraphicsScene, QGraphicsRectItem,
    QGraphicsLineItem, QProgressBar, QDialog, QDialogButtonBox,
    QLineEdit, QGroupBox, QTextEdit, QGridLayout, QHeaderView,
    QScrollBar, QFontComboBox, QStyleFactory, QDoubleSpinBox, QInputDialog, QCheckBox
)

# OpenCV for video playback
try:
    import cv2
    CV2_AVAILABLE = True
except ImportError:
    CV2_AVAILABLE = False

# ---------------------------------------------------------------------------
# Audio playback: ffplay for normal clips, pre-rendered WAVs for fade sections.
# Fade WAVs are short (only the fade duration), so ffplay speed drift is small.
# A separate FFplayAudio instance per track plays the fade WAV with priority.
# ---------------------------------------------------------------------------
try:
    import sounddevice as _sd
    import soundfile as _sf
    SD_OK = True
except ImportError:
    SD_OK = False


class FFplayAudio:
    """Wraps a single ffplay process."""
    def __init__(self):
        self._proc=None; self._lock=threading.Lock(); self._path=None; self._vol=1.0
    def load(self,path): self.stop(); self._path=path
    def play(self, start=0.0, **kw):
        self.stop()
        if not self._path: return
        cmd=[FF_PLAY,"-nodisp","-autoexit","-loglevel","quiet",
             "-ss",str(max(0.0,start)),"-af",f"volume={self._vol:.3f}",self._path]
        with self._lock:
            try: self._proc=subprocess.Popen(cmd,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,**_no_window())
            except FileNotFoundError: self._proc=None

    def stop(self):
        with self._lock:
            if self._proc and self._proc.poll() is None:
                try: self._proc.terminate(); self._proc.wait(timeout=1)
                except: pass
            self._proc=None
    def set_volume(self,v): self._vol=max(0.0,min(2.0,v))
    def is_playing(self):
        with self._lock: return self._proc is not None and self._proc.poll() is None


# Per-track players: _src for the source clip, _fade for the rendered fade WAV
AUDIO1_SRC=FFplayAudio()
AUDIO2_SRC=FFplayAudio()
AUDIO=AUDIO1_SRC   # source monitor alias

def _src_player(track_index):  return AUDIO1_SRC if track_index<=1 else AUDIO2_SRC

# Legacy aliases kept for compatibility
AUDIO1=AUDIO1_SRC; AUDIO2=AUDIO2_SRC
def _audio_for_track(ti): return _src_player(ti)

def _stop_all_audio():
    for p in (AUDIO1_SRC,AUDIO2_SRC): p.stop()



class TimelineAudioPlayer:
    """Stub kept for compatibility — not used in fade-overlay architecture."""
    def __init__(self): pass
    def stop(self): pass
    def get_player(self,idx): return _src_player(idx)

TL_AUDIO=TimelineAudioPlayer()


# Keep a single AUDIO alias so existing source-monitor code keeps working
AUDIO = AUDIO1

# Global Definitions
APP_NAME = "Video of Death"
ORG_NAME = "Death's Head Software"
VERSION = "1.0.41"


# =============================================================================
# Data Classes
# =============================================================================

class ClipType(Enum):
    VIDEO = "video"
    AUDIO = "audio"
    IMAGE = "image"
    TEXT = "text"


@dataclass
class MediaClip:
    id: str
    path: Path
    name: str
    clip_type: ClipType
    duration: float = 0.0
    fps: float = 30.0
    width: int = 1920
    height: int = 1080
    track_index: int = 0
    start_time: float = 0.0
    source_in: float = 0.0
    source_out: float = 0.0
    duration_on_timeline: float = 0.0
    volume: float = 1.0
    muted: bool = False
    opacity: float = 1.0
    text_content: Optional[str] = None
    text_position: Tuple[float, float] = (100, 100)
    text_font_size: int = 24
    text_color: str = "#FFFFFF"
    text_font: str = "Arial"
    linked_id: str = ""
    selected: bool = False
    fade_in: float = 0.0
    fade_out: float = 0.0
    crossfade_duration: float = 0.0
    text_centered: bool = False
    
    def __post_init__(self):
        if self.source_out == 0.0: self.source_out = self.duration
        if self.duration_on_timeline == 0.0: self.duration_on_timeline = self.source_out - self.source_in
    
    @property
    def end_time(self) -> float:
        return self.start_time + self.duration_on_timeline


@dataclass
class Track:
    index: int
    track_type: ClipType
    name: str
    clips: List[MediaClip] = field(default_factory=list)
    muted: bool = False
    volume: float = 1.0
    color: str = "#4a90d9"


# =============================================================================
# Splash Screen
# =============================================================================

def create_splash() -> QSplashScreen:
    try:
        splash_path = Path(__file__).parent / "splash.png"
        pixmap = None
        
        if splash_path.exists():
            pixmap = QPixmap(str(splash_path))
            if pixmap.isNull(): pixmap = None
        
        if pixmap is None:
            pixmap = QPixmap(800, 600)
            pixmap.fill(QColor(20, 20, 20))
        else:
            if pixmap.width() != 800 or pixmap.height() != 600:
                pixmap = pixmap.scaled(800, 600, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
        
        painter = QPainter(pixmap)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setPen(QColor(255, 255, 255))
        painter.setFont(QFont("Courier", 38, QFont.Weight.Bold))
        
        text_rect = pixmap.rect()
        text_rect.setTop(40)
        text_rect.setBottom(100)
        painter.drawText(text_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, APP_NAME)
        
        if pixmap.width() == 800 and pixmap.height() == 600:
            painter.setFont(QFont("Courier", 14))
            skull_art = [
                 "        ___________       ",
                 "       /           \\     ",
                 "      |  O       O  |    ",
                 "      |      ^      |    ",
                 "      |   \\_____/   |    ",
                 "       \\_         _/     ",
                 "         |_______|       ",
            ]
            y_start = 180
            for i, line in enumerate(skull_art):
                painter.drawText(250, y_start + (i * 25), line)
                
        # Footer: Moved down slightly as requested
        painter.setPen(QColor(255, 255, 255))
        painter.setFont(QFont("Courier", 14, QFont.Weight.Bold))
        footer_rect = pixmap.rect()
        footer_rect.setTop(pixmap.height() - 80)
        footer_rect.setBottom(pixmap.height() - 30)
        painter.drawText(footer_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, ORG_NAME)
        
        painter.end()
        return QSplashScreen(pixmap, Qt.WindowType.WindowStaysOnTopHint)
    except Exception as e:
        print("Splash error:", e)
        return None


# =============================================================================
# Playback Engine
# =============================================================================

class PlaybackEngine(QObject):
    frame_ready=pyqtSignal(QImage,float); time_changed=pyqtSignal(float)
    vu_meter_left=pyqtSignal(float); vu_meter_right=pyqtSignal(float)
    def __init__(self):
        super().__init__()
        self.cap=None; self.playing=False; self.paused=False
        self.current_time=0.0; self.duration=0.0; self.fps=30.0
        self.source_in=0.0; self.source_out=0.0; self.volume=1.0; self.current_clip=None
        self._pt=QTimer(); self._pt.timeout.connect(self._tick)
        self._vt=QTimer(); self._vt.timeout.connect(self._update_vu)
    def _stop_t(self): self._pt.stop(); self._vt.stop()
    def load_clip(self, clip):
        self._stop_t(); self.playing=False; self.paused=False
        if self.cap: self.cap.release(); self.cap=None
        AUDIO.stop(); self.current_clip=clip; self.current_time=0.0
        if clip.clip_type in (ClipType.VIDEO,ClipType.AUDIO): AUDIO.load(str(clip.path))
        if clip.clip_type==ClipType.IMAGE:
            self.duration=clip.duration; self.fps=1.0; self.source_in=0.0; self.source_out=clip.duration
            if CV2_AVAILABLE:
                im=cv2.imread(str(clip.path))
                if im is not None: self._emit(im, 0.0)
            return
        if clip.clip_type==ClipType.AUDIO:
            self.duration=clip.duration; self.fps=30.0; self.source_in=0.0; self.source_out=clip.duration
            try:
                import numpy as _np
                wave=_np.zeros((180,320,3),dtype='uint8'); wave[:,:]=_np.array([18,18,28],dtype='uint8')
                for x in range(4,316):
                    amp=int(72*abs(math.sin(x*0.07))*abs(math.sin(x*0.025+0.8)))
                    for dy in range(-amp,amp+1): wave[max(0,min(179,90+dy)),x]=[55,175,95]
                self.frame_ready.emit(QImage(wave.tobytes(),320,180,3*320,QImage.Format.Format_RGB888),0.0)
            except Exception: pass
            return
        if not CV2_AVAILABLE: return
        self.cap=cv2.VideoCapture(str(clip.path))
        if self.cap.isOpened():
            self.fps=max(1.0,clip.fps); self.duration=clip.duration; self.source_in=0.0; self.source_out=clip.duration
            ret,frame=self.cap.read()
            if ret: self._emit(frame,0.0)
    def play(self):
        if self.playing and not self.paused: return
        if self.paused: self.paused=False
        else:
            self.current_time=max(self.current_time,self.source_in)
            if self.cap and self.cap.isOpened():
                self.cap.set(cv2.CAP_PROP_POS_FRAMES,int(self.current_time*self.fps))
        AUDIO.set_volume(self.volume); AUDIO.play(start=self.current_time)
        self.playing=True; self._pt.start(int(1000/self.fps)); self._vt.start(50)
    def pause(self):
        self.paused=True; self.playing=False; self._stop_t(); AUDIO.stop()
    def stop(self):
        if getattr(self,'_stopping',False): return
        self._stopping=True
        try:
            self.playing=False; self.paused=False; self._stop_t(); AUDIO.stop()
            self.current_time=self.source_in; self.time_changed.emit(self.current_time)
        finally: self._stopping=False
    def seek(self,time_pos):
        self.current_time=max(self.source_in,min(time_pos,self.source_out))
        if self.cap and self.cap.isOpened() and self.current_clip and self.current_clip.clip_type!=ClipType.IMAGE:
            self.cap.set(cv2.CAP_PROP_POS_FRAMES,int(self.current_time*self.fps))
            ret,frame=self.cap.read()
            if ret: self._emit(frame,self.current_time)
        if self.playing: AUDIO.set_volume(self.volume); AUDIO.play(start=self.current_time)
        self.time_changed.emit(self.current_time)
    def _emit(self,frame,t):
        f=cv2.cvtColor(frame,cv2.COLOR_BGR2RGB); h,w,ch=f.shape
        self.frame_ready.emit(QImage(f.data.tobytes(),w,h,ch*w,QImage.Format.Format_RGB888),t)
    def _tick(self):
        if not self.playing or self.paused or getattr(self,'_stopping',False): return
        self.current_time+=1.0/self.fps
        if self.current_time>=self.source_out: self.current_time=self.source_out; self.stop(); return
        self.time_changed.emit(self.current_time)
        if self.cap and self.cap.isOpened() and self.current_clip and self.current_clip.clip_type!=ClipType.IMAGE:
            ret,frame=self.cap.read()
            if ret: self._emit(frame,self.current_time)
            else: 
                # For audio or if cap fails, continue playing (don't stop)
                if self.current_clip.clip_type == ClipType.AUDIO:
                    pass  # Keep playing audio
                else:
                    self.stop()
    def _update_vu(self):
        if not(self.playing and not self.paused): return
        t=self.current_time; sc=self.volume if AUDIO.is_playing() else 0.0
        self.vu_meter_left.emit(min(1.0,sc*abs(math.sin(t*3.5)*0.7+math.sin(t*11.2)*0.3)))
        self.vu_meter_right.emit(min(1.0,sc*abs(math.sin(t*4.1+0.4)*0.6+math.sin(t*9.8)*0.4)))
    def cleanup(self):
        self.stop(); AUDIO.stop()
        if self.cap: self.cap.release(); self.cap=None


# =============================================================================
# VU Meter Widget (FIXED: No walrus operator on attributes)
# =============================================================================

class VUMeter(QFrame):
    def __init__(self, orientation=Qt.Orientation.Vertical, parent=None):
        super().__init__(parent)
        self.orientation=orientation; self.value=0.0; self.peak_hold=0.0
        if orientation==Qt.Orientation.Vertical: self.setFixedSize(16,130)
        else: self.setFixedSize(130,16)
        self.setStyleSheet("background-color:#111;border:1px solid #222;")
        self._t=QTimer(); self._t.timeout.connect(self._decay); self._t.start(80)
    def set_value(self,v):
        self.value=max(0.0,min(1.0,v))
        if v>self.peak_hold: self.peak_hold=v
        self.update()
    def _decay(self):
        self.peak_hold=max(0.0,self.peak_hold-0.015)
        self.value=max(0.0,self.value-0.04); self.update()
    def paintEvent(self,event):
        p=QPainter(self); r=self.rect(); p.fillRect(r,QColor(10,10,10))
        if self.orientation==Qt.Orientation.Vertical:
            h=r.height()-4; filled=int(h*self.value)
            seg_g=int(h*0.75); seg_y=int(h*0.17); seg_r=h-seg_g-seg_y
            bot=r.bottom()-2; x=r.left()+2; w=r.width()-4
            if filled>0: p.fillRect(x,bot-min(filled,seg_g),w,min(filled,seg_g),QColor(40,200,40))
            if filled>seg_g: p.fillRect(x,bot-seg_g-min(filled-seg_g,seg_y),w,min(filled-seg_g,seg_y),QColor(220,200,20))
            if filled>seg_g+seg_y: p.fillRect(x,bot-seg_g-seg_y-min(filled-seg_g-seg_y,seg_r),w,min(filled-seg_g-seg_y,seg_r),QColor(220,40,40))
            if self.peak_hold>0.01:
                py=bot-int(h*self.peak_hold)
                col=QColor(220,40,40) if self.peak_hold>0.92 else (QColor(220,200,20) if self.peak_hold>0.75 else QColor(40,200,40))
                p.setPen(QPen(col,1)); p.drawLine(x,py,x+w-1,py)
        else:
            w=r.width()-4; filled=int(w*self.value)
            seg_g=int(w*0.75); seg_y=int(w*0.17)
            y=r.top()+2; h=r.height()-4
            if filled>0: p.fillRect(2,y,min(filled,seg_g),h,QColor(40,200,40))
            if filled>seg_g: p.fillRect(2+seg_g,y,min(filled-seg_g,seg_y),h,QColor(220,200,20))
            if filled>seg_g+seg_y: p.fillRect(2+seg_g+seg_y,y,filled-seg_g-seg_y,h,QColor(220,40,40))
            if self.peak_hold>0.01:
                px=2+int(w*self.peak_hold)
                col=QColor(220,40,40) if self.peak_hold>0.92 else (QColor(220,200,20) if self.peak_hold>0.75 else QColor(40,200,40))
                p.setPen(QPen(col,1)); p.drawLine(px,y,px,y+h-1)


# =============================================================================
# Source Scrub Bar — mini timeline with In/Out markers
# =============================================================================

class SourceScrubBar(QFrame):
    """Custom painted scrub bar that shows playhead + In/Out markers."""
    seek_requested = pyqtSignal(float)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.duration = 0.0; self.current = 0.0
        self.in_point = -1.0; self.out_point = -1.0
        self._dragging = False
        self.setFixedHeight(20)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setStyleSheet("background-color:#1a1a1a;border:1px solid #333;border-radius:2px;")

    def set_duration(self,d): self.duration=d; self.update()
    def set_current(self,t): self.current=t; self.update()
    def set_in(self,t): self.in_point=t; self.update()
    def set_out(self,t): self.out_point=t; self.update()
    def clear_markers(self): self.in_point=-1.0; self.out_point=-1.0; self.update()

    def _t2x(self,t): return int(t/self.duration*self.width()) if self.duration>0 else 0

    def mousePressEvent(self,e):
        self._dragging=True; self._seek(e.position().x())
    def mouseMoveEvent(self,e):
        if self._dragging: self._seek(e.position().x())
    def mouseReleaseEvent(self,e):
        self._dragging=False
    def _seek(self,px):
        if self.duration>0:
            t=max(0.0,min(self.duration, px/self.width()*self.duration))
            self.seek_requested.emit(t)

    def paintEvent(self,event):
        p=QPainter(self); r=self.rect()
        p.fillRect(r,QColor(20,20,20))
        # In/Out region
        if self.in_point>=0 and self.out_point>self.in_point:
            ix=self._t2x(self.in_point); ox=self._t2x(self.out_point)
            p.fillRect(ix,0,ox-ix,r.height(),QColor(60,120,60,120))
        # In marker
        if self.in_point>=0:
            ix=self._t2x(self.in_point)
            p.setPen(QPen(QColor(0,220,0),2)); p.drawLine(ix,0,ix,r.height())
            p.setFont(QFont("Courier",7)); p.setPen(QColor(0,200,0))
            p.drawText(ix+2,r.height()-2,"I")
        # Out marker
        if self.out_point>=0:
            ox=self._t2x(self.out_point)
            p.setPen(QPen(QColor(220,0,0),2)); p.drawLine(ox,0,ox,r.height())
            p.setFont(QFont("Courier",7)); p.setPen(QColor(200,0,0))
            p.drawText(ox-8,r.height()-2,"O")
        # Playhead
        cx=self._t2x(self.current)
        p.setPen(QPen(QColor(255,200,0),2)); p.drawLine(cx,0,cx,r.height())


# =============================================================================
# Monitor Widget
# =============================================================================

class MonitorWidget(QFrame):
    play_requested=pyqtSignal(); pause_requested=pyqtSignal(); stop_requested=pyqtSignal(); seek_requested=pyqtSignal(float)
    in_point_set=pyqtSignal(float); out_point_set=pyqtSignal(float); clip_dropped=pyqtSignal(object)

    def __init__(self, title, show_inout=True, parent=None):
        super().__init__(parent)
        self.title=title; self.show_inout=show_inout
        self.current_time=0.0; self.duration=0.0; self.in_point=0.0; self.out_point=0.0; self.playing=False
        self._overlays=[]
        self.setAcceptDrops(True); self.init_ui()

    def dragEnterEvent(self,e): e.acceptProposedAction() if e.mimeData().hasText() else e.ignore()
    def dragMoveEvent(self,e): e.acceptProposedAction() if e.mimeData().hasText() else e.ignore()
    def dropEvent(self,e):
        if not e.mimeData().hasText(): e.ignore(); return
        mw=self.window()
        if not hasattr(mw,'bin'): e.ignore(); return
        clip=next((c for c in mw.bin.media_clips if c.id==e.mimeData().text()),None)
        if clip: self.clip_dropped.emit(clip); e.acceptProposedAction()
        else: e.ignore()

    def init_ui(self):
        self.setStyleSheet("background-color:#0a0a0a;border:1px solid #444;")
        lay=QVBoxLayout(self); lay.setContentsMargins(0,0,0,0); lay.setSpacing(0)
        tb=QFrame(); tb.setStyleSheet("background-color:#2a2a2a;border-bottom:1px solid #444;")
        tl=QHBoxLayout(tb); tl.setContentsMargins(8,3,8,3)
        lbl=QLabel(self.title); lbl.setStyleSheet("color:#ccc;font-weight:bold;font-size:11px;"); tl.addWidget(lbl); tl.addStretch()
        self.in_lab=QLabel("In: --:--:--:--"); self.in_lab.setStyleSheet("color:#0f0;font-family:monospace;font-size:10px;")
        self.out_lab=QLabel("Out: --:--:--:--"); self.out_lab.setStyleSheet("color:#f00;font-family:monospace;font-size:10px;")
        self.in_lab.setCursor(Qt.CursorShape.PointingHandCursor)
        self.out_lab.setCursor(Qt.CursorShape.PointingHandCursor)
        self.in_lab.setToolTip("Click to clear In point")
        self.out_lab.setToolTip("Click to clear Out point")
        self.in_lab.mousePressEvent=lambda e: self._clear_in()
        self.out_lab.mousePressEvent=lambda e: self._clear_out()
        if self.show_inout: tl.addWidget(self.in_lab); tl.addWidget(self.out_lab)
        lay.addWidget(tb)
        self.vid_lab=QLabel(); self.vid_lab.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.vid_lab.setMinimumSize(320,180); self.vid_lab.setStyleSheet("background-color:#000;color:#555;")
        self.vid_lab.setText("No clip loaded"); lay.addWidget(self.vid_lab,1)
        # TC + VU (both right)
        vlay=QHBoxLayout(); vlay.setContentsMargins(5,2,5,2)
        self.tc=QLabel("00:00:00:00"); self.tc.setStyleSheet("color:#0f0;font-family:monospace;font-size:12px;font-weight:bold;")
        vlay.addWidget(self.tc); vlay.addStretch()
        self.vu_l=VUMeter(Qt.Orientation.Vertical); self.vu_r=VUMeter(Qt.Orientation.Vertical)
        vr=QHBoxLayout(); vr.setSpacing(2); vr.setContentsMargins(0,0,0,0)
        vr.addWidget(self.vu_l); vr.addWidget(self.vu_r); vlay.addLayout(vr)
        lay.addLayout(vlay)
        # Scrub bar (Source only)
        if self.show_inout:
            self.scrub_bar=SourceScrubBar()
            self.scrub_bar.seek_requested.connect(self.seek_requested)
            lay.addWidget(self.scrub_bar)
        else:
            self.scrub_bar=None
        # Controls
        cf=QFrame(); cf.setStyleSheet("background-color:#1a1a1a;border-top:1px solid #444;")
        cl=QHBoxLayout(cf); cl.setContentsMargins(6,4,6,4); cl.setSpacing(4)

        b_stop=QPushButton("■"); b_stop.setFixedSize(30,26)
        b_stop.setStyleSheet("QPushButton{color:#f55;background:#2a1a1a;border:1px solid #555;border-radius:3px;font-size:14px;}"
                             "QPushButton:hover{background:#3a1a1a;border-color:#f55;}")
        b_stop.setToolTip("Stop"); b_stop.clicked.connect(self.stop); cl.addWidget(b_stop)

        self.b_play=QPushButton("▶"); self.b_play.setFixedSize(36,28)
        self.b_play.setStyleSheet("QPushButton{color:#5f5;background:#1a2a1a;border:1px solid #3a7a3a;border-radius:3px;font-size:16px;font-weight:bold;}"
                                  "QPushButton:hover{background:#2a4a2a;border-color:#5f5;}")
        self.b_play.setToolTip("Play / Pause")
        self.b_play.clicked.connect(lambda:self.pause() if self.playing else self.play()); cl.addWidget(self.b_play)

        if self.show_inout:
            cl.addSpacing(8)
            bi=QPushButton("I"); bi.setFixedSize(24,24)
            bi.setStyleSheet("QPushButton{color:#0f0;background:#1a2a1a;border:1px solid #2a5a2a;border-radius:3px;font-weight:bold;font-size:11px;}"
                             "QPushButton:hover{background:#2a4a2a;}")
            bi.setToolTip("Set In point"); bi.clicked.connect(self._set_in); cl.addWidget(bi)
            bo=QPushButton("O"); bo.setFixedSize(24,24)
            bo.setStyleSheet("QPushButton{color:#f44;background:#2a1a1a;border:1px solid #5a2a2a;border-radius:3px;font-weight:bold;font-size:11px;}"
                             "QPushButton:hover{background:#3a1a1a;}")
            bo.setToolTip("Set Out point"); bo.clicked.connect(self._set_out); cl.addWidget(bo)
            bx=QPushButton("✕"); bx.setFixedSize(24,24)
            bx.setStyleSheet("QPushButton{color:#fa0;background:#2a2a1a;border:1px solid #5a5a2a;border-radius:3px;font-size:11px;}"
                             "QPushButton:hover{background:#3a3a1a;}")
            bx.setToolTip("Clear In/Out"); bx.clicked.connect(self._clear_all); cl.addWidget(bx)
            cl.addSpacing(4)
            bins=QPushButton("F9 Ins"); bins.setFixedSize(52,24)
            bins.setStyleSheet("QPushButton{color:#4af;background:#1a2a3a;border:1px solid #2a4a6a;border-radius:3px;font-size:9px;}"
                               "QPushButton:hover{background:#2a3a4a;}")
            bins.setToolTip("3-Point Insert (F9)")
            bins.clicked.connect(lambda:self.window()._insert() if hasattr(self.window(),'_insert') else None); cl.addWidget(bins)
            bow=QPushButton("F10 OW"); bow.setFixedSize(54,24)
            bow.setStyleSheet("QPushButton{color:#fa4;background:#2a2a1a;border:1px solid #6a5a2a;border-radius:3px;font-size:9px;}"
                              "QPushButton:hover{background:#3a3a1a;}")
            bow.setToolTip("3-Point Overwrite (F10)")
            bow.clicked.connect(lambda:self.window()._overwrite() if hasattr(self.window(),'_overwrite') else None); cl.addWidget(bow)
        else:
            # Program monitor: master volume slider
            cl.addSpacing(10)
            vol_lbl=QLabel("Vol:"); vol_lbl.setStyleSheet("color:#aaa;font-size:10px;"); cl.addWidget(vol_lbl)
            self.vol_slider=QSlider(Qt.Orientation.Horizontal); self.vol_slider.setRange(0,150); self.vol_slider.setValue(100)
            self.vol_slider.setFixedWidth(90); self.vol_slider.setFixedHeight(16)
            self.vol_slider.setToolTip("Master Volume 0-150%")
            self.vol_slider.setStyleSheet("QSlider::groove:horizontal{background:#333;height:4px;border-radius:2px;}"
                                          "QSlider::handle:horizontal{background:#5af;width:10px;height:10px;border-radius:5px;margin:-3px 0;}")
            cl.addWidget(self.vol_slider)
            self.vol_pct=QLabel("100%"); self.vol_pct.setStyleSheet("color:#aaa;font-size:9px;"); self.vol_pct.setFixedWidth(30); cl.addWidget(self.vol_pct)
            self.vol_slider.valueChanged.connect(lambda v:self.vol_pct.setText(f"{v}%"))

        cl.addStretch()
        lay.addWidget(cf)

    def _set_in(self):
        self.in_point=self.current_time; self.in_point_set.emit(self.current_time)
        self.in_lab.setText(f"In: {self._fmt(self.current_time)}")
        if self.scrub_bar: self.scrub_bar.set_in(self.current_time)
    def _set_out(self):
        self.out_point=self.current_time; self.out_point_set.emit(self.current_time)
        self.out_lab.setText(f"Out: {self._fmt(self.current_time)}")
        if self.scrub_bar: self.scrub_bar.set_out(self.current_time)
    def _clear_in(self):
        self.in_point=0.0; self.in_lab.setText("In: --:--:--:--")
        if self.scrub_bar: self.scrub_bar.set_in(-1.0)
        self.in_point_set.emit(0.0)
    def _clear_out(self):
        self.out_point=self.duration; self.out_lab.setText("Out: --:--:--:--")
        if self.scrub_bar: self.scrub_bar.set_out(-1.0)
        self.out_point_set.emit(self.duration)
    def _clear_all(self):
        self._clear_in(); self._clear_out()

    def set_frame(self, img, t=None):
        lw=max(1,self.vid_lab.width()); lh=max(1,self.vid_lab.height())
        scaled=img.scaled(lw,lh,Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation)
        # Paint onto a solid black canvas so letterbox/pillarbox bars are black
        canvas=QPixmap(lw,lh); canvas.fill(QColor(0,0,0))
        painter=QPainter(canvas)
        sx=(lw-scaled.width())//2; sy=(lh-scaled.height())//2
        painter.drawPixmap(sx,sy,QPixmap.fromImage(scaled))
        if self._overlays:
            for item in self._overlays:
                f=QFont(item.get('font','Arial'),item.get('size',36))
                painter.setFont(f)
                fm=painter.fontMetrics()
                txt=item['text']
                # X/Y are % of full monitor label; the coordinate is the text centre point
                cx=int(item.get('x_pct',50)/100*lw)
                cy=int(item.get('y_pct',50)/100*lh)
                px=cx - fm.horizontalAdvance(txt)//2
                py=cy + fm.ascent()//2
                painter.setPen(QPen(QColor(0,0,0,200),2)); painter.drawText(px+2,py+2,txt)
                painter.setPen(QColor(item.get('color','#FFFFFF'))); painter.drawText(px,py,txt)
        painter.end()
        self.vid_lab.setPixmap(canvas)
        if t is not None: self._upd_tc(t)

    def set_overlays(self,items): self._overlays=items

    def _upd_tc(self,t):
        self.current_time=t
        self.tc.setText(f"{int(t//3600):02d}:{int(t//60)%60:02d}:{int(t)%60:02d}:{int(t*30)%30:02d}")
        if self.scrub_bar: self.scrub_bar.set_current(t)

    def set_duration(self,d):
        self.duration=d; self.out_point=d
        if self.scrub_bar: self.scrub_bar.set_duration(d)

    def set_in_out(self,i,o):
        self.in_point=i; self.out_point=o
        self.in_lab.setText(f"In: {self._fmt(i)}"); self.out_lab.setText(f"Out: {self._fmt(o)}")
        if self.scrub_bar: self.scrub_bar.set_in(i); self.scrub_bar.set_out(o)

    def play(self):
        self.playing=True
        self.b_play.setText("⏸")
        self.b_play.setStyleSheet("QPushButton{color:#fa5;background:#2a2a1a;border:1px solid #7a7a2a;border-radius:3px;font-size:16px;font-weight:bold;}"
                                  "QPushButton:hover{background:#3a3a1a;border-color:#fa5;}")
        self.play_requested.emit()
    def pause(self):
        self.playing=False
        self.b_play.setText("▶")
        self.b_play.setStyleSheet("QPushButton{color:#5f5;background:#1a2a1a;border:1px solid #3a7a3a;border-radius:3px;font-size:16px;font-weight:bold;}"
                                  "QPushButton:hover{background:#2a4a2a;border-color:#5f5;}")
        self.pause_requested.emit()
    def stop(self):
        self.playing=False
        self.b_play.setText("▶")
        self.b_play.setStyleSheet("QPushButton{color:#5f5;background:#1a2a1a;border:1px solid #3a7a3a;border-radius:3px;font-size:16px;font-weight:bold;}"
                                  "QPushButton:hover{background:#2a4a2a;border-color:#5f5;}")
        self.stop_requested.emit()
    def _fmt(self,t): return f"{int(t//3600):02d}:{int(t//60)%60:02d}:{int(t)%60:02d}:{int(t*30)%30:02d}"


# =============================================================================
# Timeline Clip Item (Uses callbacks instead of signals)
# =============================================================================

TRIM_HANDLE_W = 8   # px — width of the trim zone at each clip edge
SNAP_PX = 8   # pixel distance to trigger snap

class TimelineClipItem(QGraphicsRectItem):
    def __init__(self, clip, pixels_per_second, tl_widget=None, parent=None):
        super().__init__(parent)
        self.clip=clip; self.pixels_per_second=pixels_per_second; self.tl=tl_widget
        self.setAcceptHoverEvents(True)
        self.setFlag(QGraphicsRectItem.GraphicsItemFlag.ItemIsMovable)
        self.setFlag(QGraphicsRectItem.GraphicsItemFlag.ItemIsSelectable)
        self.setFlag(QGraphicsRectItem.GraphicsItemFlag.ItemSendsGeometryChanges)
        self.setZValue(1)
        self.clip_clicked_cb=None; self.clip_moved_cb=None; self.clip_trimmed_cb=None
        self._trim_mode=None   # 'left' | 'right' | None
        self._trim_start_x=0.0; self._trim_orig_dur=0.0; self._trim_orig_sin=0.0; self._trim_orig_st=0.0
        self._drag_start_t=0.0
        colors={ClipType.VIDEO:(QColor(60,110,170),QColor(90,150,210)),
                ClipType.AUDIO:(QColor(100,50,160),QColor(140,80,210)),
                ClipType.IMAGE:(QColor(50,150,90),QColor(80,200,120))}
        fill,self._pc=colors.get(clip.clip_type,(QColor(80,80,80),QColor(120,120,120)))
        self.setBrush(QBrush(fill)); self.setPen(QPen(self._pc,1)); self.update_geometry()

    def update_geometry(self):
        # Minimum width = 2 trim handles + 4px gap so handles never overlap
        MIN_W = 2*TRIM_HANDLE_W + 4
        self.setRect(0,0,max(float(MIN_W),self.clip.duration_on_timeline*self.pixels_per_second),45)

    def _in_left(self,pos): return pos.x()<TRIM_HANDLE_W
    def _in_right(self,pos): return pos.x()>self.rect().width()-TRIM_HANDLE_W

    def _snap(self,t):
        # Frame-accurate: round to nearest frame boundary first
        fps=max(1.0,getattr(self.clip,'fps',30.0))
        t_frame=round(t*fps)/fps
        if not self.tl: return t_frame
        best=t_frame; bd=SNAP_PX/self.pixels_per_second
        # Snap to edit points (clip starts/ends on all tracks)
        for tr in self.tl.tracks:
            for c in tr.clips:
                for pt in (c.start_time,c.end_time):
                    pt_frame=round(pt*fps)/fps
                    d=abs(pt_frame-t_frame)
                    if d<bd: bd=d; best=pt_frame
        # Snap to playhead position too
        if self.tl and abs(self.tl.current_time-t_frame)<bd: best=self.tl.current_time
        return best
    def itemChange(self,change,value):
        if change==QGraphicsRectItem.GraphicsItemChange.ItemPositionChange:
            num_tr=len(self.tl.tracks) if self.tl else 4
            new_tr=max(0,min(int((value.y()+22)/55),num_tr-1))
            # Restrict video/image to track 0, audio to tracks 1+
            if self.clip.clip_type in (ClipType.VIDEO,ClipType.IMAGE): new_tr=0
            else: new_tr=max(1,new_tr)
            locked_y=new_tr*55
            raw_t=value.x()/self.pixels_per_second
            snapped_t=self._snap(raw_t)
            return QPointF(max(0.0,snapped_t*self.pixels_per_second),locked_y)
        return super().itemChange(change,value)

    def hoverMoveEvent(self,e):
        if self._in_left(e.pos()) or self._in_right(e.pos()):
            self.setCursor(Qt.CursorShape.SizeHorCursor)
        else:
            self.setCursor(Qt.CursorShape.ArrowCursor)
        super().hoverMoveEvent(e)
    def hoverEnterEvent(self,e): self.setOpacity(0.82); super().hoverEnterEvent(e)
    def hoverLeaveEvent(self,e): self.setOpacity(1.0); self.setCursor(Qt.CursorShape.ArrowCursor); super().hoverLeaveEvent(e)

    def mousePressEvent(self,e):
        if e.button()==Qt.MouseButton.LeftButton:
            # If the clip is too narrow for distinct trim zones, treat any click as selection
            too_narrow=self.rect().width() < 2*TRIM_HANDLE_W+4
            if not too_narrow and self._in_left(e.pos()):
                # Snapshot BEFORE modifying so the trim is undoable
                mw=self.scene().views()[0].window() if self.scene().views() else None
                if mw and hasattr(mw,'_snapshot'): mw._snapshot()
                self._trim_mode='left'
                self._trim_start_x=e.scenePos().x()
                self._trim_orig_dur=self.clip.duration_on_timeline
                self._trim_orig_sin=self.clip.source_in
                self._trim_orig_st=self.clip.start_time
                e.accept(); return
            if not too_narrow and self._in_right(e.pos()):
                mw=self.scene().views()[0].window() if self.scene().views() else None
                if mw and hasattr(mw,'_snapshot'): mw._snapshot()
                self._trim_mode='right'
                self._trim_start_x=e.scenePos().x()
                self._trim_orig_dur=self.clip.duration_on_timeline
                self._trim_orig_sin=self.clip.source_in
                e.accept(); return
        self._trim_mode=None
        ctrl=bool(e.modifiers()&Qt.KeyboardModifier.ControlModifier)
        if not ctrl and self.tl: self.tl.clear_selection()
        if self.tl: self.tl.toggle_selection(self.clip)
        if self.clip_clicked_cb: self.clip_clicked_cb(self.clip)
        # Snapshot before a potential move drag
        mw=self.scene().views()[0].window() if self.scene().views() else None
        if mw and hasattr(mw,'_snapshot'): mw._snapshot()
        super().mousePressEvent(e)

    def mouseMoveEvent(self,e):
        if self._trim_mode:
            dx=(e.scenePos().x()-self._trim_start_x)/self.pixels_per_second
            if self._trim_mode=='left':
                new_dur=max(0.1,self._trim_orig_dur-dx)
                delta=self._trim_orig_dur-new_dur
                new_sin=max(0.0,self._trim_orig_sin+delta)
                new_st=max(0.0,self._trim_orig_st+delta)
                self.clip.duration_on_timeline=new_dur
                self.clip.source_in=new_sin; self.clip.start_time=new_st
                self.setPos(new_st*self.pixels_per_second,self.y())
            else:
                new_dur=max(0.1,self._trim_orig_dur+dx)
                avail=self.clip.duration-self.clip.source_in
                if self.clip.clip_type!=ClipType.IMAGE: new_dur=min(new_dur,avail)
                self.clip.duration_on_timeline=new_dur
                self.clip.source_out=self.clip.source_in+new_dur
            self.update_geometry()
            if self.clip_trimmed_cb: self.clip_trimmed_cb(self.clip)
            e.accept(); return
        super().mouseMoveEvent(e)
        # Update track after vertical move
        if self.tl:
            num_tr=len(self.tl.tracks)
            new_tr=0 if self.clip.clip_type in (ClipType.VIDEO,ClipType.IMAGE) else max(1,min(int((self.pos().y()+22)/55),num_tr-1))
            if new_tr!=self.clip.track_index:
                if self.clip in self.tl.tracks[self.clip.track_index].clips: self.tl.tracks[self.clip.track_index].clips.remove(self.clip)
                self.clip.track_index=new_tr
                if self.clip not in self.tl.tracks[new_tr].clips: self.tl.tracks[new_tr].clips.append(self.clip)
        new_t=max(0.0,self.pos().x()/self.pixels_per_second)
        if abs(new_t-self._drag_start_t)>0.001 and self.clip_moved_cb:
            dt=new_t-self._drag_start_t; self._drag_start_t=new_t
            self.clip.start_time=new_t; self.clip_moved_cb(self.clip,new_t)
            # Move linked clip
            if self.tl and self.clip.linked_id:
                li=self.tl.clip_items.get(self.clip.linked_id)
                if li:
                    li.clip.start_time=max(0.0,li.clip.start_time+dt)
                    li.setPos(li.clip.start_time*self.pixels_per_second,li.pos().y())
            # Move all other selected clips
            if self.tl:
                for cid,item in self.tl.clip_items.items():
                    if cid!=self.clip.id and cid!=self.clip.linked_id and item.clip.selected:
                        item.clip.start_time=max(0.0,item.clip.start_time+dt)
                        item.setPos(item.clip.start_time*self.pixels_per_second,item.pos().y())

    def mouseReleaseEvent(self,e): self._trim_mode=None; self._drag_start_t=self.clip.start_time; super().mouseReleaseEvent(e)
    def mouseDoubleClickEvent(self,e):
        # Snap playhead to nearest edit point
        if not self.tl: e.accept(); return
        t=e.scenePos().x()/self.pixels_per_second
        pts=[self.clip.start_time,self.clip.end_time]
        for tr in self.tl.tracks:
            for c in tr.clips: pts+=[c.start_time,c.end_time]
        nearest=min(pts,key=lambda p:abs(p-t))
        mw=self.scene().views()[0].window() if self.scene().views() else None
        if mw and hasattr(mw,'playback'): mw.playback.seek(nearest)
        self.tl.set_current_time(nearest); e.accept()
    def contextMenuEvent(self,e):
        if self.clip_clicked_cb: self.clip_clicked_cb(self.clip)
        mw=self.scene().views()[0].window() if self.scene().views() else None
        if not mw: return
        menu=QMenu()
        menu.addAction("✂ Split at Playhead",mw._split)
        menu.addAction("🔗 Glue (Join)",mw._glue)
        if self.clip.clip_type in (ClipType.VIDEO,ClipType.IMAGE): menu.addAction("📝 Text Overlay",mw._text)
        menu.addSeparator()
        ml="🔊 Unmute" if self.clip.muted else "🔇 Mute"
        menu.addAction(ml,lambda:(setattr(self.clip,'muted',not self.clip.muted),self.update()))
        menu.addSeparator()
        menu.addAction("🗑 Delete",mw.tl.delete_selected)
        menu.exec(e.screenPos().toPoint())

    def paint(self,painter,option,widget=None):
        r=self.rect(); sel=getattr(self.clip,'selected',False)
        painter.setBrush(self.brush())
        painter.setPen(QPen(QColor(255,220,0) if sel else self._pc, 2 if sel else 1))
        painter.drawRect(r)
        if getattr(self.clip,'muted',False): painter.fillRect(r,QColor(0,0,0,100))
        painter.fillRect(int(r.left()),int(r.top()),TRIM_HANDLE_W,int(r.height()),QColor(255,255,255,30))
        painter.fillRect(int(r.right())-TRIM_HANDLE_W,int(r.top()),TRIM_HANDLE_W,int(r.height()),QColor(255,255,255,30))
        # Waveform for audio
        if self.clip.clip_type==ClipType.AUDIO:
            painter.setPen(QPen(QColor(160,120,240,200),1))
            mid=int(r.height()/2)
            for xi in range(TRIM_HANDLE_W,int(r.width())-TRIM_HANDLE_W,3):
                amp=int(14*abs(math.sin(xi*0.18+self.clip.source_in)))
                painter.drawLine(xi,mid-amp,xi,mid+amp)
        painter.setPen(QColor(255,255,255)); painter.setFont(QFont("Arial",9,QFont.Weight.Bold))
        painter.drawText(r.adjusted(TRIM_HANDLE_W+2,2,-TRIM_HANDLE_W-2,-r.height()//2),Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter,self.clip.name[:22])
        lbl=("[M] " if getattr(self.clip,'muted',False) else "")+f"{self.clip.duration_on_timeline:.1f}s"
        painter.setFont(QFont("Arial",7)); painter.setPen(QColor(180,180,180))
        painter.drawText(r.adjusted(TRIM_HANDLE_W+2,r.height()//2,-TRIM_HANDLE_W-2,-2),Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter,lbl)
        if r.width()>30 and self.clip.clip_type!=ClipType.IMAGE:
            bw=max(2,int((r.width()-8)*min(self.clip.volume,1.0))); by=int(r.bottom())-6
            painter.fillRect(int(r.left())+4,by,int(r.width())-8,4,QColor(20,20,20,180))
            painter.fillRect(int(r.left())+4,by,bw,4,QColor(40,200,40) if self.clip.volume<=1.0 else QColor(220,140,20))
        if self.clip.linked_id:
            painter.setPen(QColor(200,200,80,180)); painter.setFont(QFont("Arial",6))
            painter.drawText(int(r.left())+2,int(r.bottom())-1,"⛓")
        if getattr(self.clip,'text_content',None):
            painter.setPen(QColor(255,220,0)); painter.setFont(QFont("Arial",7))
            painter.drawText(int(r.right())-14,int(r.top())+10,"T")
        # Draw fade-in / fade-out ramps as translucent triangles
        fi=getattr(self.clip,'fade_in',0.0); fo=getattr(self.clip,'fade_out',0.0)
        if fi>0:
            fw=min(int(fi*self.pixels_per_second),int(r.width()//2))
            if fw>2:
                from PyQt6.QtGui import QPolygonF
                poly=QPolygonF([QPointF(r.left(),r.bottom()),QPointF(r.left(),r.top()),QPointF(r.left()+fw,r.top())])
                painter.setBrush(QBrush(QColor(0,0,0,120))); painter.setPen(Qt.PenStyle.NoPen); painter.drawPolygon(poly)
        if fo>0:
            fw=min(int(fo*self.pixels_per_second),int(r.width()//2))
            if fw>2:
                from PyQt6.QtGui import QPolygonF
                poly=QPolygonF([QPointF(r.right(),r.bottom()),QPointF(r.right(),r.top()),QPointF(r.right()-fw,r.top())])
                painter.setBrush(QBrush(QColor(0,0,0,120))); painter.setPen(Qt.PenStyle.NoPen); painter.drawPolygon(poly)


# =============================================================================
# Timeline Widget
# =============================================================================

class _TLView(QGraphicsView):
    playhead_dragged=pyqtSignal(float)
    def __init__(self,scene,tl,parent=None):
        super().__init__(scene,parent); self.tl=tl; self.setAcceptDrops(True)
        self.setDragMode(QGraphicsView.DragMode.NoDrag)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setStyleSheet("background-color:#111;"); self.setRenderHint(QPainter.RenderHint.Antialiasing)
        self._drag_ph=False
    def _ph_x(self): return self.tl.current_time*self.tl.pixels_per_second
    def mousePressEvent(self,e):
        if e.button()==Qt.MouseButton.LeftButton:
            sp=self.mapToScene(e.position().toPoint())
            if abs(sp.x()-self._ph_x())<10:
                self._drag_ph=True; e.accept(); return
        super().mousePressEvent(e)
    def mouseMoveEvent(self,e):
        if self._drag_ph:
            sp=self.mapToScene(e.position().toPoint())
            t=max(0.0,sp.x()/self.tl.pixels_per_second)
            self.playhead_dragged.emit(t); e.accept(); return
        super().mouseMoveEvent(e)
    def mouseReleaseEvent(self,e):
        self._drag_ph=False; super().mouseReleaseEvent(e)
        mw=self.window();
        if mw: mw.setFocus()
    def keyPressEvent(self,e):
        mw=self.window()
        if mw and e.key()==Qt.Key.Key_Space: mw.keyPressEvent(e)
        else: super().keyPressEvent(e)
    def mouseDoubleClickEvent(self,e):
        # Check if double-clicking on a clip
        item = self.itemAt(e.position().toPoint())
        if item and hasattr(item, 'clip'):
            # Double-click on a clip item
            mw = self.window()
            if mw and hasattr(mw, '_clip_dblclick'):
                mw._clip_dblclick(item.clip)
                e.accept()
                return
        
        # Otherwise, snap playhead to nearest edit point
        sp=self.mapToScene(e.position().toPoint()); t=sp.x()/self.tl.pixels_per_second
        pts=[0.0]+[p for tr in self.tl.tracks for c in tr.clips for p in (c.start_time,c.end_time)]
        nearest=min(pts,key=lambda p:abs(p-t))
        if hasattr(self.window(),'playback'): self.window().playback.seek(nearest)
        self.tl.set_current_time(nearest); e.accept()
    def contextMenuEvent(self,e):
        mw=self.window()
        if not mw: return
        menu=QMenu()
        menu.addAction("✂ Split",mw._split); menu.addAction("🔗 Glue",mw._glue); menu.addAction("📝 Text",mw._text)
        menu.addSeparator(); menu.addAction("✅ Select All",self.tl.select_all)
        menu.addAction("🗑 Delete Selected",self.tl.delete_selected)
        menu.addSeparator(); menu.addAction("➕ Zoom In",self.tl.zoom_in); menu.addAction("➖ Zoom Out",self.tl.zoom_out)
        menu.exec(e.globalPos())
    def dragEnterEvent(self,e): e.acceptProposedAction() if e.mimeData().hasText() else e.ignore()
    def dragMoveEvent(self,e): e.acceptProposedAction() if e.mimeData().hasText() else e.ignore()
    def dropEvent(self,e):
        if not e.mimeData().hasText(): e.ignore(); return
        mw=self.window()
        if not hasattr(mw,'bin'): e.ignore(); return
        clip=next((c for c in mw.bin.media_clips if c.id==e.mimeData().text()),None)
        if clip is None: e.ignore(); return
        sp=self.mapToScene(e.position().toPoint())
        drop_time=max(0.0,sp.x()/self.tl.pixels_per_second)
        track_idx=max(0,min(int(sp.y()/55),len(self.tl.tracks)-1))
        mw._drop_to_timeline(clip,drop_time,track_idx)
        e.acceptProposedAction()


class BinListWidget(QListWidget):
    def keyPressEvent(self,e):
        if e.key()==Qt.Key.Key_Space:
            mw=self.window()
            if mw: mw.keyPressEvent(e); return
        super().keyPressEvent(e)
    def mimeData(self,items):
        mime=super().mimeData(items)
        if items:
            c=items[0].data(Qt.ItemDataRole.UserRole)
            if c: mime.setText(c.id)
        return mime


class TimelineWidget(QWidget):
    clip_added=pyqtSignal(MediaClip); clip_moved=pyqtSignal(MediaClip,float); selection_changed=pyqtSignal(object)
    def __init__(self,parent=None):
        super().__init__(parent)
        self.tracks=[]; self.current_time=0.0; self.duration=300.0
        self.pixels_per_second=50.0; self.zoom_level=1.0; self.selected_clip=None; self.clip_items={}
        self.scene=QGraphicsScene(); self._setup_scene(); self.init_ui(); self._setup_tracks()
    def _sh(self): return max(55*4,55*len(self.tracks)+55)
    def _setup_scene(self): self.scene.setSceneRect(0,0,self.duration*self.pixels_per_second,self._sh())
    def init_ui(self):
        lay=QHBoxLayout(self); lay.setContentsMargins(0,0,0,0); lay.setSpacing(0)
        self.hc=QWidget(); self.hc.setFixedWidth(160); self.hc.setStyleSheet("background-color:#222;border-right:2px solid #444;")
        self.hl=QVBoxLayout(self.hc); self.hl.setContentsMargins(0,0,0,0); self.hl.setSpacing(0)
        rh=QFrame(); rh.setFixedHeight(28); rh.setStyleSheet("background-color:#1a1a1a;border-bottom:1px solid #444;"); self.hl.addWidget(rh)
        lay.addWidget(self.hc)
        right=QWidget(); rl=QVBoxLayout(right); rl.setContentsMargins(0,0,0,0); rl.setSpacing(0)
        self.ruler=TimeRuler(self.duration,self.pixels_per_second)
        self.ruler.seek_requested.connect(self._ruler_seek); rl.addWidget(self.ruler)
        self.view=_TLView(self.scene,self)
        self.view.playhead_dragged.connect(self._ruler_seek); rl.addWidget(self.view,1)
        self.hscroll=QScrollBar(Qt.Orientation.Horizontal); rl.addWidget(self.hscroll)
        self.hscroll.valueChanged.connect(lambda v:self.view.horizontalScrollBar().setValue(v))
        self.view.horizontalScrollBar().valueChanged.connect(lambda v:self.hscroll.setValue(v) if self.hscroll.value()!=v else None)
        self.view.horizontalScrollBar().rangeChanged.connect(lambda mn,mx:self.hscroll.setRange(mn,mx))
        lay.addWidget(right,1)
        self.playhead=QGraphicsLineItem(); self.playhead.setPen(QPen(QColor(255,50,50),2)); self.playhead.setZValue(100)
        self.scene.addItem(self.playhead); self.update_playhead()
    def _ruler_seek(self,t):
        mw=self.window()
        if not mw: return
        if getattr(mw,'_playing_src',True) and mw.playback.playing:
            mw.playback.seek(t)
        else:
            self.set_current_time(t)
            if hasattr(mw,'_seek_prg'): mw._seek_prg(t)
    def _setup_tracks(self):
        while self.hl.count()>2:
            item=self.hl.takeAt(1)
            if item and item.widget(): item.widget().deleteLater()
        self.tracks=[]
        # Video track
        t=Track(index=0,track_type=ClipType.VIDEO,name="Video 1"); self.tracks.append(t); self._add_hdr(t)
        # Audio tracks
        for i in range(2): t=Track(index=1+i,track_type=ClipType.AUDIO,name=f"Audio {i+1}"); self.tracks.append(t); self._add_hdr(t)
        # TEXT track - below Audio 2
        t=Track(index=3,track_type=ClipType.TEXT,name="Text"); self.tracks.append(t); self._add_hdr(t)
        self._setup_scene()
    def _add_hdr(self,tr):
        h=QFrame(); h.setFixedHeight(55); h.setStyleSheet("background-color:#222;border-bottom:1px solid #333;")
        l=QVBoxLayout(h); l.setContentsMargins(6,2,6,2); l.setSpacing(1)
        lbl=QLabel(tr.name); lbl.setStyleSheet("color:#bbb;font-size:10px;font-weight:bold;"); l.addWidget(lbl)
        if tr.track_type==ClipType.AUDIO:
            row=QHBoxLayout(); row.setSpacing(3)
            m=QPushButton("M"); m.setFixedSize(20,16); m.setCheckable(True)
            m.setStyleSheet("QPushButton{color:#888;background:#2a2a2a;border-radius:2px;font-size:9px;}QPushButton:checked{color:#fff;background:#c33;}")
            m.clicked.connect(lambda chk,t=tr:setattr(t,'muted',chk)); row.addWidget(m)
            vs=QSlider(Qt.Orientation.Horizontal); vs.setRange(0,150); vs.setValue(100); vs.setFixedWidth(50); vs.setFixedHeight(14)
            vs.setToolTip("Track volume 0-150%")
            vs.valueChanged.connect(lambda val,t=tr:setattr(t,'volume',val/100.0))
            # Also notify the editor so it can restart live audio with new volume
            vs.valueChanged.connect(lambda val,t=tr:self._notify_track_vol(t.index,val/100.0))
            row.addWidget(vs); l.addLayout(row)
        self.hl.insertWidget(self.hl.count()-1,h)
    def _notify_track_vol(self,track_idx,vol):
        """Called when a track volume slider changes — forward to VideoEditor if playing."""
        mw=self.window()
        if mw and hasattr(mw,'_on_track_vol_changed'):
            mw._on_track_vol_changed(track_idx,vol)
    def add_clip(self,clip):
        if clip.track_index>=len(self.tracks): clip.track_index=len(self.tracks)-1
        self.tracks[clip.track_index].clips.append(clip)
        item=TimelineClipItem(clip,self.pixels_per_second,self)
        item.setPos(clip.start_time*self.pixels_per_second,clip.track_index*55)
        item.clip_clicked_cb=lambda c:(setattr(self,'selected_clip',c),self.selection_changed.emit(c))
        item.clip_moved_cb=lambda c,t:(setattr(c,'start_time',max(0.0,t)),self.clip_moved.emit(c,c.start_time))
        item.clip_trimmed_cb=lambda c:None   # geometry already updated in item
        self.scene.addItem(item); self.clip_items[clip.id]=item; self.clip_added.emit(clip)
        self._setup_scene()
    def remove_clip(self,clip):
        if clip in self.tracks[clip.track_index].clips: self.tracks[clip.track_index].clips.remove(clip)
        if clip.id in self.clip_items: self.scene.removeItem(self.clip_items.pop(clip.id))
    def set_current_time(self,t):
        # Must NOT emit any signal that calls playback.seek (recursion)
        self.current_time=max(0.0,t); self.update_playhead()
    def update_playhead(self):
        x=self.current_time*self.pixels_per_second; h=self._sh()
        self.playhead.setLine(x,0,x,h)
        vr=self.view.mapToScene(self.view.viewport().rect()).boundingRect()
        if x<vr.left() or x>vr.right():
            self.view.horizontalScrollBar().setValue(max(0,int(x-self.view.viewport().width()*0.3)))
    def zoom_in(self):
        if self.zoom_level<8.0: self.zoom_level*=1.25; self.pixels_per_second=50.0*self.zoom_level; self._rezoom()
    def zoom_out(self):
        # Allow zooming out until the whole edit fits (or further).
        # The only hard floor is 0.5 px/s to avoid divide-by-zero in the ruler.
        if self.zoom_level > 0.01:
            self.zoom_level = max(0.01, self.zoom_level / 1.25)
            self.pixels_per_second = 50.0 * self.zoom_level; self._rezoom()
    def _rezoom(self):
        for item in self.clip_items.values():
            item.pixels_per_second=self.pixels_per_second; item.update_geometry()
            item.setPos(item.clip.start_time*self.pixels_per_second,item.y())
        self._setup_scene(); self.ruler.zoom=self.pixels_per_second; self.ruler.update(); self.update_playhead()
    def clear_selection(self):
        for item in self.clip_items.values(): item.clip.selected=False; item.update()
        self.selected_clip=None
    def toggle_selection(self,clip):
        clip.selected=not clip.selected
        if clip.selected: self.selected_clip=clip
        else: self.selected_clip=None
        if clip.id in self.clip_items: self.clip_items[clip.id].update()
        self.selection_changed.emit(clip if clip.selected else None)
    def select_all(self):
        for item in self.clip_items.values(): item.clip.selected=True; item.update()
        if self.clip_items: self.selected_clip=next(iter(self.clip_items.values())).clip
    def delete_selected(self):
        to_del=[item.clip for item in self.clip_items.values() if item.clip.selected]
        for c in to_del: self.remove_clip(c)
        self.selected_clip=None; self.selection_changed.emit(None)
    def get_video_clip_at_time(self,t):
        for tr in self.tracks:
            if tr.track_type==ClipType.VIDEO and not tr.muted:
                for c in tr.clips:
                    if c.start_time<=t<=c.end_time: return c
        return None


class TimeRuler(QWidget):
    seek_requested=pyqtSignal(float)
    def __init__(self,duration,zoom,parent=None):
        super().__init__(parent); self.duration=duration; self.zoom=zoom; self.setFixedHeight(28)
        self.setStyleSheet("background-color:#1a1a1a;border-bottom:1px solid #555;")
    def mousePressEvent(self,e):
        if e.button()==Qt.MouseButton.LeftButton:
            t=max(0.0,e.position().x()/self.zoom); self.seek_requested.emit(t)
    def mouseMoveEvent(self,e):
        if e.buttons()&Qt.MouseButton.LeftButton:
            t=max(0.0,e.position().x()/self.zoom); self.seek_requested.emit(t)
    def paintEvent(self,event):
        p=QPainter(self); p.fillRect(self.rect(),QColor(24,24,24)); p.setFont(QFont("Courier",8)); W=self.width()
        if self.zoom>=200: major,minor=1,0.25
        elif self.zoom>=100: major,minor=2,0.5
        elif self.zoom>=50: major,minor=5,1
        elif self.zoom>=20: major,minor=10,2
        elif self.zoom>=10: major,minor=30,5
        else: major,minor=60,10
        p.setPen(QPen(QColor(60,60,60),1)); t=0.0
        while t<=self.duration+minor:
            x=int(t*self.zoom)
            if x>W: break
            p.drawLine(x,20,x,28); t+=minor
        p.setPen(QPen(QColor(160,160,160),1)); t=0.0
        while t<=self.duration+major:
            x=int(t*self.zoom)
            if x>W: break
            p.drawLine(x,12,x,28)
            m=int(t)//60; s=int(t)%60; p.drawText(x+2,11,f"{m}:{s:02d}" if m else f"{int(t)}s")
            t+=major


# =============================================================================
# Text Overlay Dialog
# =============================================================================

class TextOverlayDialog(QDialog):
    def __init__(self, clip=None, parent=None):
        super().__init__(parent); self.clip=clip; self.setWindowTitle("Text Overlay"); self.setModal(True); self.resize(480,460); self.init_ui()
    def init_ui(self):
        lay=QVBoxLayout(self)
        g=QGroupBox("Text"); gl=QVBoxLayout(g)
        self.te=QTextEdit(); self.te.setPlaceholderText("Enter text…"); self.te.setStyleSheet("background:#1a1a1a;color:#fff;font-size:14px;")
        if self.clip and self.clip.text_content: self.te.setPlainText(self.clip.text_content)
        gl.addWidget(self.te); lay.addWidget(g)
        fg=QGroupBox("Font & Style"); fl=QGridLayout(fg)
        fl.addWidget(QLabel("Font:"),0,0); self.fc=QFontComboBox()
        if self.clip and hasattr(self.clip,'text_font'): self.fc.setCurrentFont(QFont(self.clip.text_font))
        fl.addWidget(self.fc,0,1,1,3)
        fl.addWidget(QLabel("Size:"),1,0); self.fs=QSpinBox(); self.fs.setRange(8,120)
        self.fs.setValue(self.clip.text_font_size if self.clip else 36); fl.addWidget(self.fs,1,1)
        fl.addWidget(QLabel("Color:"),1,2); self.cc=QComboBox(); self.cc.addItems(["White","Yellow","Red","Green","Blue","Orange","Black"])
        cmap={"#FFFFFF":"White","#FFFF00":"Yellow","#FF0000":"Red","#00FF00":"Green","#0055FF":"Blue","#FF8C00":"Orange","#000000":"Black"}
        if self.clip: self.cc.setCurrentText(cmap.get(self.clip.text_color,"White"))
        fl.addWidget(self.cc,1,3); lay.addWidget(fg)
        pg=QGroupBox("Position — % of full video frame  (0,0 = top-left  |  50,50 = centre  |  100,100 = bottom-right)"); pl=QGridLayout(pg)
        self.cb_center=QCheckBox("Centre in frame  (sets X=50, Y=50 — adjust freely below)")
        cur_centered=getattr(self.clip,'text_centered',False) if self.clip else False
        self.cb_center.setChecked(cur_centered)
        pl.addWidget(self.cb_center,0,0,1,4)
        pl.addWidget(QLabel("X %:"),1,0); self.xs=QSpinBox(); self.xs.setRange(0,100)
        self.xs.setValue(int(self.clip.text_position[0]) if self.clip else 50); pl.addWidget(self.xs,1,1)
        pl.addWidget(QLabel("Y %:"),1,2); self.ys=QSpinBox(); self.ys.setRange(0,100)
        self.ys.setValue(int(self.clip.text_position[1]) if self.clip else 50); pl.addWidget(self.ys,1,3)
        # When checked: snap X/Y to 50,50. Leave spinboxes enabled so user can fine-tune.
        def _on_center(checked):
            if checked:
                self.xs.setValue(50); self.ys.setValue(50)
        self.cb_center.toggled.connect(_on_center)
        lay.addWidget(pg)
        dg=QGroupBox("Duration"); dl=QHBoxLayout(dg)
        dl.addWidget(QLabel("Duration (seconds):"))
        self.dur_spin=QDoubleSpinBox(); self.dur_spin.setRange(0.5,3600.0); self.dur_spin.setSingleStep(0.5); self.dur_spin.setDecimals(1)
        cur_dur=self.clip.duration_on_timeline if self.clip and self.clip.duration_on_timeline>0 else 5.0
        self.dur_spin.setValue(cur_dur)
        dl.addWidget(self.dur_spin); dl.addStretch(); lay.addWidget(dg)
        btns=QDialogButtonBox(QDialogButtonBox.StandardButton.Ok|QDialogButtonBox.StandardButton.Cancel)
        btns.accepted.connect(self.accept); btns.rejected.connect(self.reject); lay.addWidget(btns)
    CMAP={"White":"#FFFFFF","Yellow":"#FFFF00","Red":"#FF0000","Green":"#00FF00","Blue":"#0055FF","Orange":"#FF8C00","Black":"#000000"}
    def get_text(self): return self.te.toPlainText()
    def get_position(self): return (self.xs.value(),self.ys.value())
    def get_font_size(self): return self.fs.value()
    def get_font(self): return self.fc.currentFont().family()
    def get_color(self): return self.CMAP.get(self.cc.currentText(),"#FFFFFF")
    def get_centered(self): return self.cb_center.isChecked()
    def get_duration(self): return self.dur_spin.value()


# =============================================================================
# Export Worker
# =============================================================================


class MediaBin(QDockWidget):
    clip_imported=pyqtSignal(MediaClip)
    clip_selected=pyqtSignal(object)
    def __init__(self,parent=None): super().__init__("Media Bin",parent); self.media_clips=[]; self.init_ui()
    def init_ui(self):
        self.setAllowedAreas(Qt.DockWidgetArea.LeftDockWidgetArea|Qt.DockWidgetArea.RightDockWidgetArea)
        self.setFixedWidth(240)
        c=QWidget(); lay=QVBoxLayout(c); lay.setContentsMargins(5,5,5,5); lay.setSpacing(5)
        imp=QPushButton("📁 Import Media"); imp.setStyleSheet("QPushButton{background:#3a3a3a;color:#fff;padding:8px;border-radius:4px;font-weight:bold;} QPushButton:hover{background:#4a4a4a;}")
        imp.clicked.connect(self.import_media); lay.addWidget(imp)
        self.search=QLineEdit(); self.search.setPlaceholderText("Search..."); self.search.setStyleSheet("QLineEdit{background:#1a1a1a;color:#fff;padding:5px;border:1px solid #444;border-radius:3px;}")
        self.search.textChanged.connect(self._filter); lay.addWidget(self.search)
        self.list=BinListWidget(); self.list.setStyleSheet("QListWidget{background:#1a1a1a;color:#fff;border:1px solid #333;} QListWidget::item{padding:5px;border-bottom:1px solid #2a2a2a;} QListWidget::item:selected{background:#4a90d9;}")
        self.list.setDragEnabled(True)
        self.list.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.list.customContextMenuRequested.connect(self._bin_ctx)
        self.list.currentItemChanged.connect(self._on_sel)
        self.list.itemDoubleClicked.connect(self._on_dbl)
        lay.addWidget(self.list)
        self.info=QLabel("No clip selected"); self.info.setStyleSheet("color:#888;font-size:10px;"); lay.addWidget(self.info)
        self.stats=QLabel("0 items"); self.stats.setStyleSheet("color:#666;font-size:10px;"); lay.addWidget(self.stats)
        self.setWidget(c)
    def import_media(self):
        fd=QFileDialog(); fd.setFileMode(QFileDialog.FileMode.ExistingFiles)
        fd.setNameFilter("All (*.mp4 *.avi *.mov *.mkv *.webm *.mp3 *.wav *.aac *.flac *.png *.jpg *.jpeg *.gif *.bmp *.tiff);;All (*)")
        if fd.exec():
            for f in fd.selectedFiles(): self.add_file(Path(f))
    def add_file(self, p):
        exts={'.mp4','.avi','.mov','.mkv','.webm'}; aud={'.mp3','.wav','.aac','.flac'}; img={'.png','.jpg','.jpeg','.gif','.bmp','.tiff'}
        ext=p.suffix.lower()
        if ext in exts: tp=ClipType.VIDEO
        elif ext in aud: tp=ClipType.AUDIO
        elif ext in img: tp=ClipType.IMAGE
        else: return
        dur,fps,w,h=self._info(p,tp)
        clip=MediaClip(id=f"m_{len(self.media_clips)}_{p.stem}", path=p, name=p.stem, clip_type=tp, duration=dur, fps=fps, width=w, height=h, source_out=dur)
        self.media_clips.append(clip)
        ic="🎬" if tp==ClipType.VIDEO else ("🎵" if tp==ClipType.AUDIO else "🖼️")
        it=QListWidgetItem(f"{ic} {clip.name}"); it.setData(Qt.ItemDataRole.UserRole,clip); it.setToolTip(f"{p.name}\n{dur:.2f}s")
        self.list.addItem(it); self.stats.setText(f"{len(self.media_clips)} items"); self.clip_imported.emit(clip)
    def _info(self, p, tp):
        if tp==ClipType.IMAGE:
            d=5.0
            if CV2_AVAILABLE:
                im=cv2.imread(str(p))
                if im is not None: return d,30.0,im.shape[1],im.shape[0]
            return d,30.0,1920,1080
        try:
            r=subprocess.run([FF_PROBE,"-v","quiet","-print_format","json","-show_format","-show_streams",str(p)], capture_output=True, text=True, timeout=10, **_no_window())
            d=json.loads(r.stdout); dur=float(d.get("format",{}).get("duration",10)); fps,w,h=30.0,1920,1080
            for s in d.get("streams",[]):
                if s.get("codec_type")=="video":
                    try: _n,_d=s.get("r_frame_rate","30/1").split("/"); fps=float(_n)/float(_d) if float(_d) else 30.0
                    except: fps=30.0
                    w=s.get("width",1920); h=s.get("height",1080); break
            return dur,fps,w,h
        except: return 10.0,30.0,1920,1080
    def _on_sel(self,item,_prev):
        if not item: return
        c=item.data(Qt.ItemDataRole.UserRole)
        if c: self.info.setText(f"{c.name}  |  {c.clip_type.value}  |  {c.duration:.2f}s"); self.clip_selected.emit(c)
    def _on_dbl(self,item):
        c=item.data(Qt.ItemDataRole.UserRole)
        if c: self.clip_selected.emit(c)
    def _bin_ctx(self,pos):
        it=self.list.itemAt(pos)
        if not it: return
        c=it.data(Qt.ItemDataRole.UserRole)
        menu=QMenu()
        menu.addAction("🗑 Remove from Bin",lambda:(self.list.takeItem(self.list.row(it)),self.media_clips.remove(c) if c in self.media_clips else None,self.stats.setText(f"{len(self.media_clips)} items")))
        menu.addAction("ℹ Info",lambda:QMessageBox.information(None,c.name,f"File: {c.path}\nType: {c.clip_type.value}\nDuration: {c.duration:.2f}s\n{c.width}x{c.height}"))
        menu.exec(self.list.viewport().mapToGlobal(pos))
    def _filter(self, t):
        t=t.lower()
        for i in range(self.list.count()):
            it=self.list.item(i); c=it.data(Qt.ItemDataRole.UserRole)
            it.setHidden(bool(c) and t not in c.name.lower())


# =============================================================================
# Main Window
# =============================================================================

class ExportWorker(QThread):
    progress=pyqtSignal(int); finished=pyqtSignal(bool,str); status=pyqtSignal(str)
    def __init__(self):
        super().__init__(); self.output_path=""; self.timeline=None; self.resolution="1920x1080"; self.fps=30; self.crf=23; self._stop=False
        self.preview_height=180  # height of the program monitor vid_lab — used to scale text size at export
    def stop(self): self._stop=True
    def run(self):
        try:
            cmd=self._build_cmd()
            if cmd is None: return
            self.status.emit("Running ffmpeg…")
            p=subprocess.Popen(cmd,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,universal_newlines=True,bufsize=1,**_no_window())
            tdur=max((c.end_time for tr in self.timeline.tracks for c in tr.clips),default=1)
            log=[]
            while True:
                if self._stop: p.terminate(); self.finished.emit(False,"Cancelled"); return
                line=p.stderr.readline()
                if not line:
                    if p.poll() is not None: break
                    continue
                log.append(line)
                if "time=" in line:
                    try:
                        ts=line.split("time=")[1].split()[0].split(":")
                        cur=float(ts[0])*3600+float(ts[1])*60+float(ts[2])
                        if tdur>0: self.progress.emit(min(int(cur/tdur*100),99))
                    except: pass
            p.wait()
            if p.returncode==0: self.progress.emit(100); self.finished.emit(True,"Export complete: "+self.output_path)
            else: self.finished.emit(False,"ffmpeg error ("+str(p.returncode)+"): "+"".join(log[-20:]))
        except FileNotFoundError: self.finished.emit(False,f"ffmpeg not found — expected at: {FF_MPEG}")
        except Exception as e: self.finished.emit(False,str(e))
    def _build_cmd(self):
        all_clips=[c for tr in self.timeline.tracks for c in tr.clips]
        # Sort by start_time so clips export in timeline order (critical for still images at start)
        vid=sorted([c for c in all_clips if c.clip_type in (ClipType.VIDEO,ClipType.IMAGE)],key=lambda c:c.start_time)
        # Collect IDs of video clips so we can exclude their linked audio twins.
        # A linked AUDIO clip that shares a path with a VIDEO clip already in vid
        # would be double-rendered — the video's embedded [i:a] stream already carries it.
        vid_ids={c.id for c in vid}
        vid_linked_ids={c.linked_id for c in vid if c.linked_id}
        aud_tl=sorted([c for c in all_clips
                       if c.clip_type==ClipType.AUDIO
                       and c.id not in vid_ids            # not a video clip
                       and c.id not in vid_linked_ids],   # not a clip that is the audio twin of a video
                      key=lambda c:c.start_time)
        if not vid and not aud_tl: self.finished.emit(False,"No clips on timeline."); return None
        w,h=self.resolution.split("x"); cmd=[FF_MPEG,"-y"]

        # Video inputs (may have audio streams)
        for c in vid:
            if c.clip_type==ClipType.IMAGE:
                # Images need -loop 1 so ffmpeg loops the single frame.
                # Do NOT use -ss/-t on still inputs — they have no timeline.
                cmd+=["-loop","1","-framerate",str(self.fps),"-i",str(c.path)]
            else:
                cmd+=["-accurate_seek","-ss",str(c.source_in),"-t",str(c.duration_on_timeline),"-i",str(c.path)]
        # Audio-only inputs: -vn strips embedded cover art / video streams from mp3 etc.
        # -accurate_seek ensures the trim is frame-accurate so afade timing is correct.
        for c in aud_tl:
            cmd+=["-accurate_seek","-ss",str(c.source_in),"-t",str(c.duration_on_timeline),"-vn","-i",str(c.path)]

        nv=len(vid); na=len(aud_tl)

        # Audio-only export
        if nv==0:
            if na==1: cmd+=["-c:a","aac","-b:a","192k",self.output_path]; return cmd
            fc="".join(f"[{i}:a]" for i in range(na))+f"amix=inputs={na}:normalize=0[outa]"
            cmd+=["-filter_complex",fc,"-map","[outa]","-c:a","aac","-b:a","192k",self.output_path]; return cmd

        fc=[]
        # Video filter chain
        for i,c in enumerate(vid):
            if c.clip_type==ClipType.IMAGE:
                # -loop 1 input gives infinite frames; trim to exact clip duration
                fc.append(f"[{i}:v]scale={w}:{h}:force_original_aspect_ratio=decrease,"
                          f"pad={w}:{h}:(ow-iw)/2:(oh-ih)/2,setsar=1,fps={self.fps},"
                          f"trim=duration={c.duration_on_timeline:.3f},setpts=PTS-STARTPTS[v{i}]")
            else:
                fc.append(f"[{i}:v]scale={w}:{h}:force_original_aspect_ratio=decrease,"
                          f"pad={w}:{h}:(ow-iw)/2:(oh-ih)/2,setsar=1,fps={self.fps}[v{i}]")
        fc.append("".join(f"[v{i}]" for i in range(nv))+f"concat=n={nv}:v=1:a=0[outv]")

        # Audio: only from VIDEO clips (not IMAGE — they have no audio), plus standalone audio clips
        # For video clips, fades are stored on the *linked* AUDIO clip (set via Audio menu).
        audio_labels=[]
        # Build a lookup: clip_id → clip object for all audio clips
        all_audio={c.id:c for c in all_clips if c.clip_type==ClipType.AUDIO}
        for i,c in enumerate(vid):
            if c.clip_type==ClipType.VIDEO:
                linked=all_audio.get(c.linked_id) if c.linked_id else None
                fi=getattr(linked,'fade_in',0.0) if linked else getattr(c,'fade_in',0.0)
                fo=getattr(linked,'fade_out',0.0) if linked else getattr(c,'fade_out',0.0)
                delay_ms=int(c.start_time*1000)
                # Apply afade BEFORE adelay — afade sees timestamps 0..clip_dur so
                # st values are straightforward.  adelay then shifts the whole thing.
                filt=f"[{i}:a]asetpts=PTS-STARTPTS"
                if fi>0: filt+=f",afade=t=in:st=0:d={fi:.3f}"
                if fo>0:
                    fade_st=max(0.0,c.duration_on_timeline-fo)
                    filt+=f",afade=t=out:st={fade_st:.3f}:d={fo:.3f}"
                if delay_ms>0: filt+=f",adelay={delay_ms}:all=1"
                filt+=f"[va{i}]"; fc.append(filt); audio_labels.append(f"[va{i}]")
        for i,c in enumerate(aud_tl):
            delay_ms=int(c.start_time*1000)
            fi=getattr(c,'fade_in',0.0); fo=getattr(c,'fade_out',0.0)
            filt=f"[{nv+i}:a]asetpts=PTS-STARTPTS"
            if fi>0: filt+=f",afade=t=in:st=0:d={fi:.3f}"
            if fo>0:
                fade_st=max(0.0,c.duration_on_timeline-fo)
                filt+=f",afade=t=out:st={fade_st:.3f}:d={fo:.3f}"
            if delay_ms>0: filt+=f",adelay={delay_ms}:all=1"
            filt+=f"[aa{i}]"; fc.append(filt); audio_labels.append(f"[aa{i}]")

        n_aud=len(audio_labels)
        if n_aud==1:
            fc.append(f"{audio_labels[0]}anull[outa]")
        elif n_aud>1:
            fc.append("".join(audio_labels)+f"amix=inputs={n_aud}:normalize=0[outa]")

        # TEXT track clips → drawtext filters chained onto [outv]
        text_clips=[c for tr in self.timeline.tracks if tr.track_type==ClipType.TEXT
                    for c in tr.clips if getattr(c,'text_content',None)]
        vid_out="[outv]"
        for ti,tc in enumerate(text_clips):
            col=getattr(tc,'text_color','#FFFFFF').lstrip('#')
            # Scale font size from preview monitor height to export frame height.
            # This makes text appear the same relative size in the export as in the Program monitor.
            preview_h=max(1,getattr(self,'preview_height',180))
            export_h=int(h)
            sz_preview=getattr(tc,'text_font_size',36)
            sz=max(8,round(sz_preview*export_h/preview_h))
            # In subprocess list args ffmpeg receives the string as-is (no shell).
            # Commas inside option values must be escaped as \, for ffmpeg's own
            # filter parser, but only within the option value — NOT in the enable
            # expression which uses its own syntax.
            txt=getattr(tc,'text_content','').replace('\\','\\\\').replace("'","\\'").replace(':','\\:').replace(',','\\,')
            xpct=tc.text_position[0]/100.0; ypct=tc.text_position[1]/100.0
            en=f"between(t,{tc.start_time:.3f},{tc.end_time:.3f})"
            next_lbl=f"[vtxt{ti}]"
            # x/y are the centre point of the text (matching preview behaviour)
            x_expr=f"w*{xpct:.4f}-text_w/2"; y_expr=f"h*{ypct:.4f}-text_h/2"
            fc.append(f"{vid_out}drawtext=text='{txt}':fontsize={sz}:fontcolor=0x{col}FF"
                      f":x={x_expr}:y={y_expr}:enable='{en}':shadowx=2:shadowy=2{next_lbl}")
            vid_out=next_lbl

        if n_aud>0:
            cmd+=["-filter_complex",";".join(fc),"-map",vid_out,"-map","[outa]"]
        else:
            cmd+=["-filter_complex",";".join(fc),"-map",vid_out,"-an"]
        # yuv420p is universally compatible (required for most players including Windows Media Player).
        # CRF 0 = visually lossless with libx264; truly lossless would need a different codec
        # but produces files most players cannot open.
        cmd+=["-c:v","libx264","-preset","medium","-crf",str(self.crf),"-pix_fmt","yuv420p",
              "-c:a","aac","-b:a","192k","-r",str(self.fps),"-movflags","+faststart",self.output_path]
        return cmd


# =============================================================================
# Media Bin
# =============================================================================


class VideoEditor(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(APP_NAME); self.setGeometry(50,50,1600,1000)
        self.playback=PlaybackEngine(); self.export_worker=ExportWorker()
        self.source_in=0.0; self.source_out=0.0; self._playing_src=True
        self._tl_clips=[]; self._tl_time=0.0; self._tl_end=0.0
        self._tl_cap=None; self._tl_cur=None; self._tl_fps=30.0
        self._tl_timer=QTimer(); self._tl_timer.setInterval(33); self._tl_timer.timeout.connect(self._tl_tick)
        self._undo_stack=[]; self._redo_stack=[]; self._project_path=None
        self.init_ui(); self.init_menu(); self.init_toolbar(); self._connect()
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus); self.setFocus()
        self.statusBar().showMessage("Ready  ·  Space=play  ·  I/O=in/out  ·  Del=delete  ·  Ctrl+K=split  ·  Double-click timeline=snap to edit")
    def init_ui(self):
        self.setMinimumSize(1400, 900)
        c=QWidget(); self.setCentralWidget(c); main=QHBoxLayout(c); main.setContentsMargins(0,0,0,0); main.setSpacing(0)
        self.bin=MediaBin(self); main.addWidget(self.bin)
        ctr=QWidget(); cl=QVBoxLayout(ctr); cl.setContentsMargins(0,0,0,0); cl.setSpacing(0)
        mon=QSplitter(Qt.Orientation.Horizontal)
        self.src_mon=MonitorWidget("Source",show_inout=True); self.prg_mon=MonitorWidget("Program",show_inout=False)
        mon.addWidget(self.src_mon); mon.addWidget(self.prg_mon)
        mon.setStretchFactor(0,1); mon.setStretchFactor(1,1)
        cl.addWidget(mon)
        # Timeline goes directly in the layout — it has its own internal scrolling
        self.tl=TimelineWidget(); self.tl.setMinimumHeight(300)
        cl.addWidget(self.tl)
        main.addWidget(ctr,1)
        # Properties panel — floats in lower-left corner so it never covers the timeline
        pp=QDockWidget("Properties",self); pp.setAllowedAreas(Qt.DockWidgetArea.AllDockWidgetAreas)
        pp.setMinimumWidth(220); pp.setMaximumWidth(280)
        pw=QWidget(); pl=QVBoxLayout(pw)
        ci=QGroupBox("Clip Info"); il=QVBoxLayout(ci); self.ci_lab=QLabel("No clip selected"); self.ci_lab.setWordWrap(True); il.addWidget(self.ci_lab); pl.addWidget(ci)
        pl.addStretch(); pp.setWidget(pw)
        self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea,pp)
        pp.setFloating(True); pp.resize(240,140)
        self._pp=pp   # keep reference for View menu and _sel()
    def init_menu(self):
        mb=self.menuBar()
        fm=mb.addMenu("File")
        fm.addAction(QAction("New",self,shortcut="Ctrl+N",triggered=self._new_project))
        fm.addAction(QAction("Open Project...",self,shortcut="Ctrl+O",triggered=self._open_project))
        fm.addAction(QAction("Save Project",self,shortcut="Ctrl+S",triggered=self._save_project))
        fm.addAction(QAction("Close Project",self,triggered=self._close_project))
        fm.addSeparator()
        ea=QAction("Export Video...",self); ea.setShortcut("Ctrl+E"); ea.triggered.connect(self.export_video); fm.addAction(ea); fm.addSeparator()
        xa=QAction("Exit",self); xa.setShortcut("Ctrl+Q"); xa.triggered.connect(self.close); fm.addAction(xa)
        em=mb.addMenu("Edit")
        em.addAction(QAction("Undo",self,shortcut="Ctrl+Z",triggered=self._undo))
        em.addAction(QAction("Redo",self,shortcut="Ctrl+Y",triggered=self._redo))
        em.addSeparator()
        da=QAction("Delete",self); da.setShortcut("Delete"); da.triggered.connect(self.tl.delete_selected); em.addAction(da); em.addSeparator()
        sa=QAction("Split at Playhead",self); sa.setShortcut("Ctrl+K"); sa.triggered.connect(self._split); em.addAction(sa); em.addSeparator()
        ia=QAction("3-Point Insert",self); ia.setShortcut("F9"); ia.triggered.connect(self._insert); em.addAction(ia)
        oa=QAction("3-Point Overwrite",self); oa.setShortcut("F10"); oa.triggered.connect(self._overwrite); em.addAction(oa)
        ga=QAction("Glue (Join) Clips",self); ga.setShortcut("Ctrl+J"); ga.triggered.connect(self._glue); em.addAction(ga)
        vm=mb.addMenu("View")
        za=QAction("Zoom In",self); za.setShortcuts(["Ctrl++","Ctrl+="]); za.triggered.connect(self.tl.zoom_in); vm.addAction(za)
        zo=QAction("Zoom Out",self); zo.setShortcut("Ctrl+-"); zo.triggered.connect(self.tl.zoom_out); vm.addAction(zo)
        vm.addAction(QAction("Zoom to Fit",self,shortcut="Ctrl+0",triggered=self._zoom_fit))
        vm.addSeparator()
        pa=QAction("Properties",self,shortcut="Ctrl+P"); pa.triggered.connect(self._show_properties); vm.addAction(pa)
        tm=mb.addMenu("Text"); ta=QAction("Add Text...",self); ta.setShortcut("Ctrl+T"); ta.triggered.connect(self._text); tm.addAction(ta)
        # Audio menu
        afm=mb.addMenu("Audio")
        afm.addAction(QAction("Fade In",self,triggered=self._fade_in_audio))
        afm.addAction(QAction("Fade Out",self,triggered=self._fade_out_audio))
        afm.addAction(QAction("Remove Fades",self,triggered=self._remove_fades_audio))
        afm.addSeparator()
        afm.addAction(QAction("Render Fade Preview",self,triggered=self._render_fade_preview))
        afm.addAction(QAction("Render All Fade Previews",self,triggered=self._render_all_fade_previews))
        hm=mb.addMenu("Help"); aa=QAction("About",self); aa.triggered.connect(self.show_about); hm.addAction(aa)
    def _act(self, m, t, s=""): a=QAction(t,self); a.setShortcut(s); m.addAction(a)
    def init_toolbar(self):
        tb=QToolBar("Tools"); tb.setMovable(False); self.addToolBar(tb)
        tb.addAction("✂️ Split",self._split); tb.addSeparator(); tb.addAction("📝 Text",self._text)
        tb.addAction("🎬 Insert",self._insert); tb.addAction("📺 Overwrite",self._overwrite); tb.addSeparator()
        tb.addAction("➕ Zoom",self.tl.zoom_in); tb.addAction("➖ Zoom",self.tl.zoom_out); tb.addSeparator()
        eb=QPushButton("🎥 Export"); eb.setStyleSheet("QPushButton{background:#4a90d9;color:#fff;padding:5px 15px;border-radius:3px;font-weight:bold;}"); eb.clicked.connect(self.export_video); tb.addWidget(eb)
    def _connect(self):
        src=self.src_mon; prg=self.prg_mon
        src.play_requested.connect(self._play_src)
        src.pause_requested.connect(self.playback.pause); src.stop_requested.connect(self.playback.stop)
        src.seek_requested.connect(self.playback.seek)
        src.in_point_set.connect(lambda t:(setattr(self,'source_in',t),src.set_in_out(t,self.source_out if self.source_out>t else t+0.1)))
        src.out_point_set.connect(lambda t:(setattr(self,'source_out',t),src.set_in_out(self.source_in,t)))
        src.clip_dropped.connect(self._load_source)
        prg.play_requested.connect(self._play_prg)
        prg.pause_requested.connect(self._pause_prg)
        # Timeline clip selection -> Properties panel
        self.tl.selection_changed.connect(self._sel)
        prg.stop_requested.connect(self._stop_prg)
        prg.seek_requested.connect(self._seek_prg)
        self.tl.selection_changed.connect(self._sel)
        # No tl.time_changed → playback.seek (causes recursion)
        self.playback.frame_ready.connect(self._dispatch_frame)
        self.playback.time_changed.connect(self._on_time)
        self.playback.vu_meter_left.connect(src.vu_l.set_value); self.playback.vu_meter_right.connect(src.vu_r.set_value)
        self.playback.vu_meter_left.connect(prg.vu_l.set_value); self.playback.vu_meter_right.connect(prg.vu_r.set_value)
        self.bin.clip_selected.connect(self._load_source)
        # Master volume is the slider in the Program monitor control bar
        self.mv=self.prg_mon.vol_slider
        self.mv.valueChanged.connect(self._mv_changed)
        self._last_mv_val=self.mv.value()
    def _seek_prg(self,t):
        was=self._tl_timer.isActive()
        self._tl_timer.stop(); _stop_all_audio()
        if self._tl_cap: self._tl_cap.release(); self._tl_cap=None
        self._tl_cur=None
        self.tl.set_current_time(t)
        self.prg_mon.current_time=t
        self.prg_mon.tc.setText(f"{int(t//3600):02d}:{int(t//60)%60:02d}:{int(t)%60:02d}:{int(t*30)%30:02d}")
        # Collect text overlays active at t
        def _ov(c):
            if not getattr(c,'text_content',None): return []
            return [{'text':c.text_content,'font':getattr(c,'text_font','Arial'),'size':getattr(c,'text_font_size',36),'color':getattr(c,'text_color','#FFFFFF'),'x_pct':c.text_position[0],'y_pct':c.text_position[1],'centered':getattr(c,'text_centered',False)}]
        text_ov=[]
        for tr in self.tl.tracks:
            if tr.track_type==ClipType.TEXT and not tr.muted:
                for tc in tr.clips:
                    if tc.start_time<=t<tc.end_time: text_ov.extend(_ov(tc))
        clip=self.tl.get_video_clip_at_time(t)
        if clip is None:
            pm=QPixmap(max(1,self.prg_mon.vid_lab.width()),max(1,self.prg_mon.vid_lab.height()))
            pm.fill(QColor(0,0,0)); self.prg_mon.vid_lab.setPixmap(pm)
        elif CV2_AVAILABLE and clip.clip_type==ClipType.VIDEO:
            try:
                cap=cv2.VideoCapture(str(clip.path))
                if cap.isOpened():
                    off=t-clip.start_time+clip.source_in
                    cap.set(cv2.CAP_PROP_POS_FRAMES,int(off*clip.fps))
                    ret,frame=cap.read()
                    if ret:
                        f=cv2.cvtColor(frame,cv2.COLOR_BGR2RGB); hh,ww,ch=f.shape
                        img=QImage(f.data.tobytes(),ww,hh,ch*ww,QImage.Format.Format_RGB888)
                        self.prg_mon.set_overlays(text_ov); self.prg_mon.set_frame(img,t)
                cap.release()
            except: pass
        elif clip and clip.clip_type==ClipType.IMAGE and CV2_AVAILABLE:
            try:
                im=cv2.imread(str(clip.path))
                if im is not None:
                    f=cv2.cvtColor(im,cv2.COLOR_BGR2RGB); hh,ww,ch=f.shape
                    self.prg_mon.set_overlays(text_ov); self.prg_mon.set_frame(QImage(f.data.tobytes(),ww,hh,ch*ww,QImage.Format.Format_RGB888),t)
            except: pass
        if was: self._play_prg()
    def _pause_prg(self):
        self._tl_timer.stop(); _stop_all_audio()
        if self._tl_cap: self._tl_cap.release(); self._tl_cap=None
        self._tl_cur=None
        self.playback.pause()
    def _stop_prg(self):
        # Do NOT call _stop_tl here — that calls prg_mon.stop() which re-emits stop_requested → recursion
        self._tl_timer.stop(); _stop_all_audio()
        if self._tl_cap: self._tl_cap.release(); self._tl_cap=None
        self._tl_cur=None; self._tl_clips=[]; self._tl_aud_state={}
        self.playback.stop()
        self.tl.set_current_time(0.0); self.prg_mon._upd_tc(0.0)
    def _zoom_fit(self):
        all_ends=[c.end_time for tr in self.tl.tracks for c in tr.clips]
        if not all_ends: return
        edit_dur=max(all_ends)+2
        vw=max(1,self.tl.view.viewport().width())
        self.tl.zoom_level=(vw/edit_dur)/50.0
        self.tl.pixels_per_second=vw/edit_dur
        self.tl._rezoom()
        self.statusBar().showMessage(f"Zoom to fit: {edit_dur:.1f}s")
    def _on_track_vol_changed(self,track_idx,tr_vol):
        if not self._tl_timer.isActive(): return
        # Debounce: restart ffplay 150ms after slider settles to avoid
        # constant restarts while dragging
        if not hasattr(self,'_vol_timers'): self._vol_timers={}
        if track_idx not in self._vol_timers:
            t=QTimer(); t.setSingleShot(True)
            t.timeout.connect(lambda ti=track_idx: self._apply_track_vol(ti))
            self._vol_timers[track_idx]=t
        self._vol_timers[track_idx].start(150)

    def _apply_track_vol(self,track_idx):
        if not self._tl_timer.isActive(): return
        tr_obj=next((t for t in self.tl.tracks if t.index==track_idx),None)
        if not tr_obj: return
        master=self.mv.value()/100.0
        clip_id=self._tl_aud_state.get(track_idx)
        if not clip_id: return
        ac=next((c for tr in self.tl.tracks for c in tr.clips if c.id==clip_id),None)
        if not ac: return
        p=_src_player(track_idx)
        p.set_volume(master*tr_obj.volume*ac.volume)
        off=max(0.0,self._tl_time-ac.start_time)
        # Preserve the rendered fade file if one exists — otherwise reloading
        # the raw source here would replace the faded preview mid-playback.
        if (getattr(ac,'fade_in',0.0)>0 or getattr(ac,'fade_out',0.0)>0) and _render_exists(ac.id):
            p.load(_render_path_for_existing(ac.id))
            p.play(start=off)
        else:
            p.load(str(ac.path))
            p.play(start=ac.source_in+off)

    def _mv_changed(self,v):
        if v==getattr(self,'_last_mv_val',None): return
        self._last_mv_val=v
        vol=v/100.0; self.playback.volume=vol; AUDIO.set_volume(vol)
        if self._tl_timer.isActive():
            for tr_idx,clip_id in list(self._tl_aud_state.items()):
                if not clip_id: continue
                ac=next((c for tr in self.tl.tracks for c in tr.clips if c.id==clip_id),None)
                if not ac: continue
                tr_obj=next((t for t in self.tl.tracks if t.index==tr_idx),None)
                tr_vol=tr_obj.volume if tr_obj else 1.0
                p=_src_player(tr_idx)
                p.set_volume(vol*tr_vol*ac.volume)
                off=max(0.0,self._tl_time-ac.start_time)
                # Preserve rendered fade file (otherwise touching the master
                # volume during playback would silently swap to the raw source).
                if (getattr(ac,'fade_in',0.0)>0 or getattr(ac,'fade_out',0.0)>0) and _render_exists(ac.id):
                    p.load(_render_path_for_existing(ac.id))
                    p.play(start=off)
                else:
                    p.load(str(ac.path))
                    p.play(start=ac.source_in+off)
    def _load_source(self,clip):
        self._stop_tl()
        # Stop timers safely before loading new clip
        self.playback._pt.stop(); self.playback._vt.stop()
        self.playback.playing=False; self.playback.paused=False
        self.playback.load_clip(clip)
        self.playback.source_in=0.0; self.playback.source_out=clip.duration
        self.source_in=0.0; self.source_out=clip.duration
        self.src_mon.set_duration(clip.duration)
        self.src_mon.in_lab.setText("In: --:--:--:--"); self.src_mon.out_lab.setText("Out: --:--:--:--")
        if self.src_mon.scrub_bar: self.src_mon.scrub_bar.clear_markers()
        self._playing_src=True
        pm=QPixmap(max(1,self.prg_mon.vid_lab.width()),max(1,self.prg_mon.vid_lab.height())); pm.fill(QColor(0,0,0))
        self.prg_mon.vid_lab.setPixmap(pm)
        self.statusBar().showMessage(f"Source: {clip.name}  ({clip.duration:.2f}s)")
    def _play_src(self):
        it=self.bin.list.currentItem()
        if it:
            c=it.data(Qt.ItemDataRole.UserRole); self.playback.load_clip(c)
            self.playback.source_in=self.source_in
            self.playback.source_out=self.source_out if self.source_out>self.source_in else c.duration
            self.src_mon.set_duration(c.duration); self._playing_src=True
        self.playback.play()
    def _play_prg(self):
        self._playing_src=False
        # Stop source engine without emitting time_changed (avoids re-entry during tick)
        self.playback._pt.stop(); self.playback._vt.stop()
        self.playback.playing=False; self.playback.paused=False
        AUDIO.stop(); _stop_all_audio()
        self._tl_clips=sorted([c for tr in self.tl.tracks if tr.track_type==ClipType.VIDEO and not tr.muted for c in tr.clips if c.clip_type in (ClipType.VIDEO,ClipType.IMAGE)],key=lambda c:c.start_time)
        if not self._tl_clips:
            # Audio-only timeline: play audio, show black
            pm=QPixmap(max(1,self.prg_mon.vid_lab.width()),max(1,self.prg_mon.vid_lab.height()))
            pm.fill(QColor(0,0,0)); self.prg_mon.vid_lab.setPixmap(pm)
            # Find audio end time
            aud_end=max((c.end_time for tr in self.tl.tracks for c in tr.clips),default=0)
            if aud_end==0: return
            self._tl_end=aud_end; self._tl_fps=30.0; self._tl_timer.setInterval(33); self._tl_timer.start()
            self.prg_mon.playing=True; self.prg_mon.b_play.setText('⏸')
            self.prg_mon.b_play.setStyleSheet("QPushButton{color:#fa5;background:#2a2a1a;border:1px solid #7a7a2a;border-radius:3px;font-size:16px;font-weight:bold;}")
        start_t=self.tl.current_time
        self._tl_time=start_t
        # Wall-clock anchor: _tl_time will be derived from time.monotonic() each tick
        # rather than accumulated from frame counts. Frame-counting drifts whenever
        # a tick takes longer than its interval (OpenCV decode latency, Qt event-loop
        # jitter on Windows), causing the timeline playhead to race ahead of audio
        # which is driven by ffplay's wall-clock. Drift made fade-outs sound early
        # because the audio fade landed at its true wall-clock time, but the visible
        # playhead said we were further along than we actually were.
        self._tl_play_origin=start_t
        self._tl_wall_start=time.monotonic()
        # _tl_end must be the latest end time across ALL tracks (video AND audio),
        # not just video clips — audio on Audio 2 commonly extends past the last video cut.
        self._tl_end=max(c.end_time for tr in self.tl.tracks for c in tr.clips)
        self._tl_cap=None; self._tl_cur=None; self._tl_fps=30.0; self._tl_aud_state={}
        self._load_tl_clip(start_t)
        # Render first frame immediately so Program isn't blank on first tick
        if self._tl_cur and self._tl_cap and self._tl_cap.isOpened():
            ret,frame=self._tl_cap.read()
            if ret:
                f=cv2.cvtColor(frame,cv2.COLOR_BGR2RGB); hh,ww,ch=f.shape
                img=QImage(f.data.tobytes(),ww,hh,ch*ww,QImage.Format.Format_RGB888)
                self.prg_mon.set_overlays([]); self.prg_mon.set_frame(img,start_t)
        if self._tl_cur is None:
            pm=QPixmap(max(1,self.prg_mon.vid_lab.width()),max(1,self.prg_mon.vid_lab.height()))
            pm.fill(QColor(0,0,0)); self.prg_mon.vid_lab.setPixmap(pm)
        self._tl_timer.start()
        # Update play button directly — do NOT call prg_mon.play() as it emits play_requested → _play_prg → recursion
        self.prg_mon.playing=True
        self.prg_mon.b_play.setText('⏸')
        self.prg_mon.b_play.setStyleSheet("QPushButton{color:#fa5;background:#2a2a1a;border:1px solid #7a7a2a;border-radius:3px;font-size:16px;font-weight:bold;}")
        # Start audio — whole-clip rendered WAVs swap in cleanly at clip boundary
        _stop_all_audio()
        self._tl_aud_state={1:None,2:None}
        master=self.mv.value()/100.0
        for tr in self.tl.tracks:
            if tr.track_type!=ClipType.AUDIO or tr.muted: continue
            ac=next((c for c in tr.clips if c.start_time<=start_t<c.end_time),None)
            if not ac: continue
            self._tl_aud_state[tr.index]=ac.id
            off=start_t-ac.start_time
            p=_src_player(tr.index)
            p.set_volume(master*tr.volume*ac.volume)
            # If a rendered fade preview exists for this clip, play that instead
            # of the raw source. Rendered file is already trimmed to source_in..source_out
            # so playback offset is just `off` (relative to clip start on timeline).
            if (getattr(ac,'fade_in',0.0)>0 or getattr(ac,'fade_out',0.0)>0) and _render_exists(ac.id):
                rp=_render_path_for_existing(ac.id)
                p.load(rp)
                p.play(start=off)
                print(f"[FADE] init-play track={tr.index} clip={ac.name} file={os.path.basename(rp)} off={off:.3f}s fi={ac.fade_in:.2f} fo={ac.fade_out:.2f}",flush=True)
                self.statusBar().showMessage(f"Playing fade preview: {os.path.basename(rp)} (offset {off:.2f}s)",4000)
            else:
                p.load(str(ac.path))
                p.play(start=ac.source_in+off)
                print(f"[FADE] init-play RAW track={tr.index} clip={ac.name} fi={getattr(ac,'fade_in',0):.2f} fo={getattr(ac,'fade_out',0):.2f} render_exists={_render_exists(ac.id)}",flush=True)
    def _load_tl_clip(self,t):
        clip=next((c for c in self._tl_clips if c.start_time<=t<c.end_time),None)
        if clip is self._tl_cur: return
        if self._tl_cap: self._tl_cap.release(); self._tl_cap=None
        self._tl_cur=clip
        if clip and clip.clip_type==ClipType.IMAGE:
            self._tl_fps=30.0; self._tl_timer.setInterval(33); return
        if clip and CV2_AVAILABLE:
            cap=cv2.VideoCapture(str(clip.path))
            if cap.isOpened():
                off=t-clip.start_time+clip.source_in
                cap.set(cv2.CAP_PROP_POS_FRAMES,int(off*clip.fps))
                self._tl_cap=cap; self._tl_fps=max(1.0,clip.fps)
                self._tl_timer.setInterval(int(1000/self._tl_fps))
            else:
                cap.release(); self._tl_cap=None
    def _tl_tick(self):
        if not self._tl_clips: self._stop_tl(); return
        # Wall-clock derived time — guarantees A/V sync with ffplay regardless
        # of timer jitter or decode latency. ffplay drives audio off real time,
        # so anchoring video to real time keeps both clocks aligned.
        if hasattr(self,'_tl_wall_start'):
            self._tl_time=self._tl_play_origin+(time.monotonic()-self._tl_wall_start)
        else:
            self._tl_time+=1.0/self._tl_fps  # fallback for any path that didn't set the anchor
        if self._tl_time>=self._tl_end: self._stop_tl(); return
        # --- Audio: drive each audio track independently -------------------
        # Collect the active clip (if any) for each audio track separately
        aud_by_track={}   # track_index → clip
        for tr in self.tl.tracks:
            if tr.track_type==ClipType.AUDIO and not tr.muted:
                for c in tr.clips:
                    if c.start_time<=self._tl_time<c.end_time:
                        aud_by_track[tr.index]=c; break
        # Audio: per-clip source playback + fade overlay management
        if not hasattr(self,'_tl_aud_state'): self._tl_aud_state={}
        for _i in (1,2):
            if _i not in self._tl_aud_state: self._tl_aud_state[_i]=None
        master=self.mv.value()/100.0
        for tr_idx in (1,2):
            src=_src_player(tr_idx)
            new_clip=aud_by_track.get(tr_idx)
            new_id=new_clip.id if new_clip else None
            prev_id=self._tl_aud_state.get(tr_idx)
            if new_id!=prev_id:
                src.stop()
                self._tl_aud_state[tr_idx]=new_id
                if new_clip:
                    tr_obj=next((t for t in self.tl.tracks if t.index==tr_idx),None)
                    tr_vol=tr_obj.volume if tr_obj else 1.0
                    src.set_volume(master*tr_vol*new_clip.volume)
                    off=self._tl_time-new_clip.start_time
                    if (getattr(new_clip,'fade_in',0.0)>0 or getattr(new_clip,'fade_out',0.0)>0) and _render_exists(new_clip.id):
                        rp=_render_path_for_existing(new_clip.id)
                        src.load(rp)
                        src.play(start=off)
                        print(f"[FADE] tl-tick track={tr_idx} clip={new_clip.name} file={os.path.basename(rp)} off={off:.3f}s fi={new_clip.fade_in:.2f} fo={new_clip.fade_out:.2f}",flush=True)
                    else:
                        src.load(str(new_clip.path))
                        src.play(start=new_clip.source_in+off)
                        print(f"[FADE] tl-tick RAW track={tr_idx} clip={new_clip.name} fi={getattr(new_clip,'fade_in',0):.2f} fo={getattr(new_clip,'fade_out',0):.2f} render_exists={_render_exists(new_clip.id)}",flush=True)
        self.tl.set_current_time(self._tl_time)
        t=self._tl_time
        self.prg_mon.current_time=t
        self.prg_mon.tc.setText(f"{int(t//3600):02d}:{int(t//60)%60:02d}:{int(t)%60:02d}:{int(t*30)%30:02d}")
        self._load_tl_clip(self._tl_time)
        clip=self._tl_cur
        def _ov(c):
            if not getattr(c,'text_content',None): return []
            return [{'text':c.text_content,'font':getattr(c,'text_font','Arial'),'size':getattr(c,'text_font_size',36),'color':getattr(c,'text_color','#FFFFFF'),'x_pct':c.text_position[0],'y_pct':c.text_position[1],'centered':getattr(c,'text_centered',False)}]
        # Collect text overlays from TEXT track clips active at this time
        text_overlays=[]
        for tr in self.tl.tracks:
            if tr.track_type==ClipType.TEXT and not tr.muted:
                for tc in tr.clips:
                    if tc.start_time<=self._tl_time<tc.end_time:
                        text_overlays.extend(_ov(tc))
        if clip and clip.clip_type==ClipType.IMAGE and CV2_AVAILABLE:
            if not hasattr(self,'_img_cache'): self._img_cache={}
            key=str(clip.path)
            if key not in self._img_cache:
                try:
                    im=cv2.imread(str(clip.path))
                    if im is not None:
                        f=cv2.cvtColor(im,cv2.COLOR_BGR2RGB); hh,ww,ch=f.shape
                        self._img_cache[key]=QImage(f.data.tobytes(),ww,hh,ch*ww,QImage.Format.Format_RGB888)
                    else: self._img_cache[key]=None
                except Exception as e: print(f'Image load error: {e}'); self._img_cache[key]=None
            if self._img_cache.get(key) is not None:
                self.prg_mon.set_overlays(_ov(clip)+text_overlays); self.prg_mon.set_frame(self._img_cache[key],self._tl_time)
        elif clip and self._tl_cap and self._tl_cap.isOpened():
            ret,frame=self._tl_cap.read()
            if ret:
                f=cv2.cvtColor(frame,cv2.COLOR_BGR2RGB); hh,ww,ch=f.shape
                img=QImage(f.data.tobytes(),ww,hh,ch*ww,QImage.Format.Format_RGB888)
                self.prg_mon.set_overlays(_ov(clip)+text_overlays); self.prg_mon.set_frame(img,self._tl_time)
            else:
                # Video frame ran out (clip ended or decode error). Release the capture
                # and show black, but DO NOT stop the timeline — audio on track 2
                # commonly extends past the last video cut, and stopping here would
                # cut off audio fade-outs partway through, making them sound early.
                # The main _tl_time>=_tl_end check will stop us at the true end.
                self._tl_cap.release(); self._tl_cap=None; self._tl_cur=None
                pm=QPixmap(max(1,self.prg_mon.vid_lab.width()),max(1,self.prg_mon.vid_lab.height()))
                pm.fill(QColor(0,0,0)); self.prg_mon.vid_lab.setPixmap(pm)
        else:
            # Gap in video — show black but still display any text overlays
            if text_overlays:
                pm=QPixmap(max(1,self.prg_mon.vid_lab.width()),max(1,self.prg_mon.vid_lab.height()))
                pm.fill(QColor(0,0,0))
                black=QImage(max(1,self.prg_mon.vid_lab.width()),max(1,self.prg_mon.vid_lab.height()),QImage.Format.Format_RGB888)
                black.fill(QColor(0,0,0))
                self.prg_mon.set_overlays(text_overlays); self.prg_mon.set_frame(black,self._tl_time)
            else:
                pm=QPixmap(max(1,self.prg_mon.vid_lab.width()),max(1,self.prg_mon.vid_lab.height()))
                pm.fill(QColor(0,0,0)); self.prg_mon.vid_lab.setPixmap(pm)
        t=self._tl_time; sc=self.playback.volume if (AUDIO1.is_playing() or AUDIO2.is_playing()) else 0.0
        self.prg_mon.vu_l.set_value(min(1.0,sc*abs(math.sin(t*3.5)*0.7+math.sin(t*11.2)*0.3)))
        self.prg_mon.vu_r.set_value(min(1.0,sc*abs(math.sin(t*4.1+0.4)*0.6+math.sin(t*9.8)*0.4)))
    def _stop_tl(self):
        self._tl_timer.stop(); _stop_all_audio()
        if hasattr(self,'_tl_cap') and self._tl_cap: self._tl_cap.release(); self._tl_cap=None
        self._tl_cur=None; self._tl_clips=[]; self._tl_aud_state={}
        # Update button state without emitting stop_requested (that would recurse via _stop_prg)
        self.prg_mon.playing=False; self.prg_mon.b_play.setText('▶')
        self.prg_mon.b_play.setStyleSheet("QPushButton{color:#5f5;background:#1a2a1a;border:1px solid #3a7a3a;border-radius:3px;font-size:16px;font-weight:bold;}")
    def _dispatch_frame(self,img,t):
        if self._playing_src: self.src_mon.set_overlays([]); self.src_mon.set_frame(img,t)
    def _on_time(self,t): self.src_mon._upd_tc(t)
    def _snapshot(self):
        self._undo_stack.append([copy.copy(c) for tr in self.tl.tracks for c in tr.clips])
        if len(self._undo_stack)>50: self._undo_stack.pop(0)
        self._redo_stack.clear()
    def _undo(self):
        if not self._undo_stack: self.statusBar().showMessage("Nothing to undo"); return
        self._redo_stack.append([copy.copy(c) for tr in self.tl.tracks for c in tr.clips])
        self._restore_snap(self._undo_stack.pop())
    def _redo(self):
        if not self._redo_stack: self.statusBar().showMessage("Nothing to redo"); return
        self._undo_stack.append([copy.copy(c) for tr in self.tl.tracks for c in tr.clips])
        self._restore_snap(self._redo_stack.pop())
    def _restore_snap(self,snap):
        for tr in self.tl.tracks:
            for c in list(tr.clips): self.tl.remove_clip(c)
        for c in snap: self.tl.add_clip(c)
        self.statusBar().showMessage("Restored")

    def _close_project(self):
        """Close current project, clear timeline AND media bin."""
        has_clips = any(t.clips for t in self.tl.tracks) if self.tl.tracks else False
        has_bin   = bool(self.bin.media_clips)
        if has_clips or has_bin:
            ret = QMessageBox.question(self, "Close Project",
                                      "Clear timeline and media bin?",
                                      QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
            if ret == QMessageBox.StandardButton.No:
                return
        # Stop playback first
        self._stop_tl()
        try: self.playback.stop()
        except: pass
        # Remove every scene item that belongs to a clip, then clear data
        for item in list(self.tl.clip_items.values()):
            self.tl.scene.removeItem(item)
        self.tl.clip_items.clear()
        for track in self.tl.tracks:
            track.clips.clear()
        self.tl.selected_clip = None
        self.tl._setup_scene()
        # Clear media bin
        self.bin.media_clips.clear()
        self.bin.list.clear()
        self.bin.stats.setText("0 items")
        self.bin.info.setText("No clip selected")
        # Reset undo history and project path
        self._undo_stack.clear()
        self._redo_stack.clear()
        self._project_path = None
        self._sel(None)
        # Clear Source monitor
        self.playback.stop()
        self.src_mon.vid_lab.setText("No clip loaded")
        self.src_mon.vid_lab.setPixmap(QPixmap())
        self.src_mon._upd_tc(0.0)
        if self.src_mon.scrub_bar: self.src_mon.scrub_bar.clear_markers()
        # Clear Program monitor
        pm=QPixmap(max(1,self.prg_mon.vid_lab.width()),max(1,self.prg_mon.vid_lab.height()))
        pm.fill(QColor(0,0,0)); self.prg_mon.vid_lab.setPixmap(pm)
        self.prg_mon._upd_tc(0.0)
        self.statusBar().showMessage("Project closed")


    def _render_audio_fades(self):
        """Inform the user about the new live preview behavior."""
        QMessageBox.information(self,"Audio Fades",
            "Audio fades are now previewed live on the timeline.\n\n"
            "Set fade in/out via the Audio menu — a short offline\n"
            "render runs automatically so playback uses the faded\n"
            "audio. Export uses the same filter for identical results.")

    def _render_clip_fade_modal(self,c):
        """Render a clip's fade preview off-UI-thread with a modal progress dialog.

        Called whenever a clip's fade values change or via Audio → Render Fade
        Preview. The modal stays responsive while ffmpeg runs. On failure the
        captured ffmpeg stderr is shown so the user can diagnose what went wrong."""
        from PyQt6.QtWidgets import QProgressDialog
        result={'path':None,'log':''}
        def log_cb(msg): result['log']=msg
        def worker():
            result['path']=_render_fade_clip(c, log_cb=log_cb)
        th=threading.Thread(target=worker,daemon=True); th.start()
        prog=QProgressDialog(f"Rendering fade preview for '{c.name}'…","",0,0,self)
        prog.setWindowTitle("Audio Fade Preview")
        prog.setCancelButton(None)
        prog.setMinimumDuration(0)
        prog.setWindowModality(Qt.WindowModality.ApplicationModal)
        prog.show()
        while th.is_alive():
            QApplication.processEvents()
            th.join(0.05)
        prog.close()
        if result['path'] is None and result['log']:
            QMessageBox.warning(self,"Fade Preview Render Failed",
                                f"Could not render fade preview for '{c.name}'.\n\n"
                                f"{result['log']}\n\n"
                                "Export will still apply fades correctly.")
        return result['path']

    def _fade_in_audio(self):
        """Apply fade-in to selected audio clip and render preview offline."""
        c = self.tl.selected_clip
        if not c or c.clip_type != ClipType.AUDIO:
            QMessageBox.warning(self, "Fade In", "Select an audio clip on the timeline first.")
            return
        dur, ok = QInputDialog.getDouble(self, "Fade In Duration",
                                        f"Fade-in duration in seconds (max {c.duration_on_timeline:.2f}s):",
                                        1.0, 0.1, c.duration_on_timeline, 2)
        if ok:
            # Stop playback so the new render isn't fighting an in-flight ffplay
            try: self._stop_tl()
            except Exception: pass
            c.fade_in = dur
            _invalidate_render(c.id)
            out=self._render_clip_fade_modal(c)
            if c.id in self.tl.clip_items: self.tl.clip_items[c.id].update()
            if out:
                self.statusBar().showMessage(f"Fade-in {dur:.2f}s set on '{c.name}' — preview ready (press Play)")
            else:
                self.statusBar().showMessage(f"Fade-in {dur:.2f}s set on '{c.name}' — preview render failed (export still works)")

    def _fade_out_audio(self):
        """Apply fade-out to selected audio clip and render preview offline."""
        c = self.tl.selected_clip
        if not c or c.clip_type != ClipType.AUDIO:
            QMessageBox.warning(self, "Fade Out", "Select an audio clip on the timeline first.")
            return
        dur, ok = QInputDialog.getDouble(self, "Fade Out Duration",
                                        f"Fade-out duration in seconds (max {c.duration_on_timeline:.2f}s):",
                                        1.0, 0.1, c.duration_on_timeline, 2)
        if ok:
            try: self._stop_tl()
            except Exception: pass
            c.fade_out = dur
            _invalidate_render(c.id)
            out=self._render_clip_fade_modal(c)
            if c.id in self.tl.clip_items: self.tl.clip_items[c.id].update()
            if out:
                self.statusBar().showMessage(f"Fade-out {dur:.2f}s set on '{c.name}' — preview ready (press Play)")
            else:
                self.statusBar().showMessage(f"Fade-out {dur:.2f}s set on '{c.name}' — preview render failed (export still works)")
    def _remove_fades_audio(self):
        """Remove fade-in and fade-out from the selected audio clip and clear cached preview."""
        c = self.tl.selected_clip
        if not c or c.clip_type != ClipType.AUDIO:
            QMessageBox.warning(self, "Remove Fades", "Select an audio clip on the timeline first.")
            return
        try: self._stop_tl()
        except Exception: pass
        c.fade_in = 0.0; c.fade_out = 0.0
        _invalidate_render(c.id)
        if c.id in self.tl.clip_items: self.tl.clip_items[c.id].update()
        self.statusBar().showMessage(f"Fades removed from '{c.name}'")

    def _render_fade_preview(self):
        """Re-render the fade preview for the selected audio clip.

        Use this if the initial auto-render failed, if you trimmed the clip
        after setting fades, or if you want to force a fresh render."""
        c = self.tl.selected_clip
        if not c or c.clip_type != ClipType.AUDIO:
            QMessageBox.warning(self, "Render Fade Preview",
                                "Select an audio clip on the timeline first.")
            return
        if getattr(c,'fade_in',0.0)<=0 and getattr(c,'fade_out',0.0)<=0:
            QMessageBox.information(self, "Render Fade Preview",
                                    f"'{c.name}' has no fade-in or fade-out set.\n\n"
                                    "Use Audio → Fade In / Fade Out first.")
            return
        try: self._stop_tl()
        except Exception: pass
        _invalidate_render(c.id)
        out=self._render_clip_fade_modal(c)
        if out:
            self.statusBar().showMessage(f"Fade preview rendered for '{c.name}' — press Play")
        # On failure, _render_clip_fade_modal already showed the error dialog.

    def _render_all_fade_previews(self):
        """Re-render fade previews for every audio clip on the timeline that has fades."""
        targets=[]
        for tr in self.tl.tracks:
            if tr.track_type!=ClipType.AUDIO: continue
            for c in tr.clips:
                if getattr(c,'fade_in',0.0)>0 or getattr(c,'fade_out',0.0)>0:
                    targets.append(c)
        if not targets:
            QMessageBox.information(self, "Render All Fade Previews",
                                    "No audio clips on the timeline have fades set.")
            return
        try: self._stop_tl()
        except Exception: pass
        ok=0; fail=0
        for c in targets:
            _invalidate_render(c.id)
            if self._render_clip_fade_modal(c): ok+=1
            else: fail+=1
        self.statusBar().showMessage(
            f"Rendered {ok}/{len(targets)} fade previews"+(f" ({fail} failed)" if fail else ""))
    def _render_timeline(self):
        """Bake text overlays and audio fades into the preview.
        Clears the still-image frame cache so _tl_tick re-reads images fresh,
        then does a quick pass to confirm all TEXT clips have content.
        Audio fades are applied at export time via ffmpeg; this shows a
        status message confirming fades are registered."""
        # Clear image cache so stills pick up any overlay changes on next play
        if hasattr(self,'_img_cache'): self._img_cache.clear()
        # Report what will be rendered
        text_clips=[c for tr in self.tl.tracks if tr.track_type==ClipType.TEXT for c in tr.clips if getattr(c,'text_content',None)]
        fade_clips=[c for tr in self.tl.tracks for c in tr.clips if getattr(c,'fade_in',0.0)>0 or getattr(c,'fade_out',0.0)>0]
        parts=[]
        if text_clips: parts.append(f"{len(text_clips)} text overlay(s)")
        if fade_clips: parts.append(f"{len(fade_clips)} clip(s) with audio fades (applied at export)")
        if not parts: parts.append("no text or fades found")
        self.statusBar().showMessage(f"Render Timeline: {', '.join(parts)}. Press Space/L to preview.")

    def _new_project(self):
        if QMessageBox.question(self,"New","Start new project? Unsaved changes lost.",
                QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No)==QMessageBox.StandardButton.Yes:
            for tr in self.tl.tracks:
                for c in list(tr.clips): self.tl.remove_clip(c)
            self.bin.media_clips.clear(); self.bin.list.clear()
            self._undo_stack.clear(); self._redo_stack.clear(); self._project_path=None
            self.statusBar().showMessage("New project")
    def _save_project(self):
        path=self._project_path
        if not path:
            path,_=QFileDialog.getSaveFileName(self,"Save Project","","VOD Project (*.vod)")
            if not path: return
            if not path.endswith('.vod'): path+='.vod'
        try:
            import json as _j
            data={'clips':[],'bin':[]}
            for tr in self.tl.tracks:
                for c in tr.clips:
                    data['clips'].append({'id':c.id,'path':str(c.path),'name':c.name,'type':c.clip_type.value,
                        'duration':c.duration,'fps':c.fps,'width':c.width,'height':c.height,
                        'track':c.track_index,'start':c.start_time,'source_in':c.source_in,
                        'source_out':c.source_out,'dur_tl':c.duration_on_timeline,'volume':c.volume,
                        'linked':c.linked_id,
                        'fade_in':getattr(c,'fade_in',0.0),'fade_out':getattr(c,'fade_out',0.0),
                        'text':c.text_content or '',
                        'text_font':getattr(c,'text_font','Arial'),'text_font_size':getattr(c,'text_font_size',36),
                        'text_color':getattr(c,'text_color','#FFFFFF'),
                        'text_centered':getattr(c,'text_centered',False),
                        'text_pos_x':c.text_position[0],'text_pos_y':c.text_position[1]})
            for c in self.bin.media_clips:
                data['bin'].append({'path':str(c.path),'name':c.name,'type':c.clip_type.value})
            data['cursor']=self.tl.current_time
            data['zoom']=self.tl.zoom_level
            open(path,'w').write(_j.dumps(data,indent=2))
            self._project_path=path; self.statusBar().showMessage(f"Saved: {path}")
        except Exception as ex: QMessageBox.critical(self,"Save Error",str(ex))
    def _open_project_path(self,path):
        try:
            import json as _j
            ct={'video':ClipType.VIDEO,'audio':ClipType.AUDIO,'image':ClipType.IMAGE,'text':ClipType.TEXT}
            data=_j.loads(open(path).read())
            for tr in self.tl.tracks:
                for c in list(tr.clips): self.tl.remove_clip(c)
            self.bin.media_clips.clear(); self.bin.list.clear()
            for bd in data.get('bin',[]):
                try: self.bin.add_file(Path(bd['path']))
                except: pass
            for cd in data.get('clips',[]):
                c=MediaClip(id=cd['id'],path=Path(cd['path']),name=cd['name'],
                    clip_type=ct.get(cd['type'],ClipType.VIDEO),
                    duration=cd['duration'],fps=cd['fps'],width=cd['width'],height=cd['height'],
                    track_index=cd['track'],start_time=cd['start'],source_in=cd['source_in'],
                    source_out=cd['source_out'],duration_on_timeline=cd['dur_tl'],volume=cd['volume'],
                    linked_id=cd.get('linked',''),
                    fade_in=cd.get('fade_in',0.0),fade_out=cd.get('fade_out',0.0),
                    text_content=cd.get('text','') or None,
                    text_font=cd.get('text_font','Arial'),
                    text_font_size=cd.get('text_font_size',36),
                    text_color=cd.get('text_color','#FFFFFF'),
                    text_centered=cd.get('text_centered',False),
                    text_position=(cd.get('text_pos_x',10),cd.get('text_pos_y',85)))
                self.tl.add_clip(c)
            self._project_path=path
            if 'cursor' in data: self.tl.set_current_time(data['cursor'])
            if 'zoom' in data:
                self.tl.zoom_level=data['zoom']; self.tl.pixels_per_second=50.0*data['zoom']; self.tl._rezoom()
            self.statusBar().showMessage(f"Opened: {path}")
        except Exception as ex: QMessageBox.critical(self,"Open Error",str(ex))
    def _open_project(self):
        path,_=QFileDialog.getOpenFileName(self,"Open Project","","VOD Project (*.vod)")
        if not path: return
        self._open_project_path(path)
    def _drop_to_timeline(self,clip,drop_time,track_idx):
        self._snapshot(); ts=int(time.time()*1000)
        if clip.clip_type==ClipType.VIDEO:
            # Split video to Video 1, audio to first available audio track
            video_tracks = [t for t in self.tl.tracks if t.track_type == ClipType.VIDEO]
            audio_tracks = [t for t in self.tl.tracks if t.track_type == ClipType.AUDIO]
            v_idx = video_tracks[0].index if video_tracks else 0
            a_idx = audio_tracks[0].index if audio_tracks else 2
            
            vc=copy.copy(clip); vc.id=f"tl_v_{clip.id}_{ts}"; vc.track_index=v_idx; vc.start_time=drop_time; vc.source_in=0.0; vc.source_out=clip.duration; vc.duration_on_timeline=clip.duration; vc.selected=False
            ac=copy.copy(clip); ac.id=f"tl_a_{clip.id}_{ts}"; ac.clip_type=ClipType.AUDIO; ac.track_index=a_idx; ac.start_time=drop_time; ac.source_in=0.0; ac.source_out=clip.duration; ac.duration_on_timeline=clip.duration; ac.selected=False
            vc.linked_id=ac.id; ac.linked_id=vc.id
            self.tl.add_clip(vc); self.tl.add_clip(ac)
            vc.selected=True; ac.selected=True
            if vc.id in self.tl.clip_items: self.tl.clip_items[vc.id].update()
            if ac.id in self.tl.clip_items: self.tl.clip_items[ac.id].update()
            self.tl.selected_clip=vc
            v_name = self.tl.tracks[v_idx].name if v_idx < len(self.tl.tracks) else "Video 1"
            a_name = self.tl.tracks[a_idx].name if a_idx < len(self.tl.tracks) else "Audio 1"
            self.statusBar().showMessage(f"Added '{clip.name}' → {v_name} + {a_name} at {drop_time:.1f}s")
        elif clip.clip_type==ClipType.IMAGE:
            nc=copy.copy(clip); nc.id=f"tl_{clip.id}_{ts}"; nc.track_index=0; nc.start_time=drop_time; nc.source_in=0.0; nc.source_out=clip.duration; nc.duration_on_timeline=clip.duration; nc.selected=False
            self.tl.add_clip(nc); self.statusBar().showMessage(f"Added image '{clip.name}' at {drop_time:.1f}s")
        else:  # AUDIO
            # Always insert audio on Audio 1 or Audio 2 track
            audio_tracks = [t for t in self.tl.tracks if t.track_type == ClipType.AUDIO]
            if audio_tracks:
                # Use first available audio track
                tgt = audio_tracks[0].index
            else:
                tgt = 2  # Default to Audio 1 if somehow no audio tracks
            nc=copy.copy(clip); nc.id=f"tl_{clip.id}_{ts}"; nc.track_index=tgt; nc.start_time=drop_time; nc.source_in=0.0; nc.source_out=clip.duration; nc.duration_on_timeline=clip.duration; nc.selected=False
            self.tl.add_clip(nc); track_name = self.tl.tracks[tgt].name if tgt < len(self.tl.tracks) else "Audio 1"
            self.statusBar().showMessage(f"Added audio '{clip.name}' at {drop_time:.1f}s on {track_name}")
    def _sel(self, c):
        """Update properties panel with selected clip info"""
        if c:
            vol_pct = int(c.volume * 100) if hasattr(c, 'volume') else 100
            text_info = ""
            if c.clip_type.value == "text" and hasattr(c, 'text_content'):
                text_info = f"\nText: {c.text_content[:50]}" if c.text_content else ""
            info = f"Name: {c.name}\nType: {c.clip_type.value}\nDur: {c.duration_on_timeline:.2f}s\nStart: {c.start_time:.2f}s\nVol: {vol_pct}%{text_info}"
            self.ci_lab.setText(info)
        else:
            self.ci_lab.setText("No clip selected")
    
    def _clip_dblclick(self, clip):
        """Double-click handler for clips in timeline"""
        if clip.clip_type == ClipType.AUDIO:
            self._show_audio_volume_dialog(clip)
        elif clip.clip_type == ClipType.TEXT:
            self._show_text_edit_dialog(clip)
    
    def _show_audio_volume_dialog(self, clip):
        """Show volume adjustment dialog for audio clip"""
        dlg = QDialog(self)
        dlg.setWindowTitle(f"Audio Volume: {clip.name}")
        dlg.setFixedSize(350, 150)
        lay = QVBoxLayout(dlg)
        
        lay.addWidget(QLabel(f"Clip: {clip.name}"))
        
        vol_lay = QHBoxLayout()
        vol_lay.addWidget(QLabel("Volume:"))
        vol_spin = QDoubleSpinBox()
        vol_spin.setRange(0.0, 2.0)
        vol_spin.setValue(clip.volume)
        vol_spin.setSingleStep(0.1)
        vol_spin.setDecimals(1)
        vol_lay.addWidget(vol_spin)
        vol_lay.addWidget(QLabel("(0.0 = mute, 1.0 = normal, 2.0 = 2x)"))
        lay.addLayout(vol_lay)
        
        lay.addStretch()
        
        btns = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        btns.accepted.connect(lambda: (setattr(clip, 'volume', vol_spin.value()), dlg.accept()))
        btns.rejected.connect(dlg.reject)
        lay.addWidget(btns)
        
        dlg.exec()
        self.statusBar().showMessage(f"Audio volume: {clip.volume*100:.0f}%")
    
    def _show_text_edit_dialog(self, clip):
        """Show text editing dialog for text clip"""
        if clip.clip_type != ClipType.TEXT:
            return
        d = TextOverlayDialog(clip, self)
        if d.exec() == QDialog.DialogCode.Accepted:
            dur = d.get_duration()
            clip.text_content = d.get_text()
            clip.text_position = d.get_position()
            clip.text_font_size = d.get_font_size()
            clip.text_color = d.get_color()
            clip.text_font = d.get_font()
            clip.text_centered = d.get_centered()
            clip.duration_on_timeline = dur
            clip.source_out = dur
            # Update the visual geometry on the timeline
            if clip.id in self.tl.clip_items:
                self.tl.clip_items[clip.id].update_geometry()
                self.tl.clip_items[clip.id].update()
            self.statusBar().showMessage(f"Text updated: {clip.name}  ({dur:.1f}s)")
    def _insert(self):
        self._snapshot(); it=self.bin.list.currentItem()
        if not it: QMessageBox.warning(self,"Insert","Select source clip"); return
        c=it.data(Qt.ItemDataRole.UserRole)
        ts=int(time.time()*1000)
        sin=self.source_in; sout=self.source_out if self.source_out>self.source_in else c.duration; dur=sout-sin
        if c.clip_type==ClipType.VIDEO:
            video_tracks=[t for t in self.tl.tracks if t.track_type==ClipType.VIDEO]
            audio_tracks=[t for t in self.tl.tracks if t.track_type==ClipType.AUDIO]
            v_idx=video_tracks[0].index if video_tracks else 0
            a_idx=audio_tracks[0].index if audio_tracks else 1
            vc=copy.copy(c); vc.id=f"tl_v_{c.id}_{ts}"; vc.track_index=v_idx; vc.start_time=self.tl.current_time; vc.source_in=sin; vc.source_out=sout; vc.duration_on_timeline=dur; vc.selected=False
            ac=copy.copy(c); ac.id=f"tl_a_{c.id}_{ts}"; ac.clip_type=ClipType.AUDIO; ac.track_index=a_idx; ac.start_time=self.tl.current_time; ac.source_in=sin; ac.source_out=sout; ac.duration_on_timeline=dur; ac.selected=False
            vc.linked_id=ac.id; ac.linked_id=vc.id
            self.tl.add_clip(vc); self.tl.add_clip(ac)
        else:
            if c.clip_type==ClipType.AUDIO:
                audio_tracks=[t for t in self.tl.tracks if t.track_type==ClipType.AUDIO]
                tr_idx=audio_tracks[0].index if audio_tracks else 1
            else:
                tr_idx=next((t.index for t in self.tl.tracks if t.track_type==c.clip_type),0)
            nc=copy.copy(c); nc.id=f"tl_{c.id}_{ts}"; nc.track_index=tr_idx; nc.start_time=self.tl.current_time; nc.source_in=sin; nc.source_out=sout; nc.duration_on_timeline=dur; nc.selected=False
            self.tl.add_clip(nc)
    def _overwrite(self): self._insert()
    def _split(self):
        self._snapshot()  # save undo state
        # If nothing selected, try to find a clip at the playhead
        if not self.tl.selected_clip:
            c=self.tl.get_video_clip_at_time(self.tl.current_time)
            if not c:
                for tr in self.tl.tracks:
                    for cl in tr.clips:
                        if cl.start_time<=self.tl.current_time<=cl.end_time: c=cl; break
                    if c: break
            if not c: QMessageBox.information(self,"Split","No clip at playhead — click a clip to select it first."); return
            self.tl.selected_clip=c
        c=self.tl.selected_clip; pt=self.tl.current_time; rel=pt-c.start_time
        if rel<=0 or rel>=c.duration_on_timeline: QMessageBox.warning(self,"Split","Playhead must be inside the selected clip."); return
        ts=int(time.time()*1000)
        nc=copy.copy(c); nc.id=f"{c.id}_sp{ts}"; nc.name=f"{c.name} B"
        nc.start_time=pt; nc.source_in=c.source_in+rel; nc.source_out=c.source_out; nc.duration_on_timeline=c.source_out-(c.source_in+rel)
        nc.linked_id=""; nc.selected=False
        c.source_out=c.source_in+rel; c.duration_on_timeline=rel; c.linked_id=""
        c.selected=False  # deselect left clip
        if c.id in self.tl.clip_items: self.tl.clip_items[c.id].update_geometry(); self.tl.clip_items[c.id].update()
        self.tl.add_clip(nc)
        # Select the right (B) clip automatically
        nc.selected=True; self.tl.selected_clip=nc
        if nc.id in self.tl.clip_items: self.tl.clip_items[nc.id].update()
        self.statusBar().showMessage(f"Split '{c.name}' at {pt:.2f}s — right clip selected")
    def _glue(self):
        self._snapshot(); c=self.tl.selected_clip
        if not c: QMessageBox.information(self,"Glue","Select the FIRST of two adjacent clips."); return
        tr=self.tl.tracks[c.track_index]
        # Find clip that starts exactly where c ends
        next_c=next((x for x in tr.clips if abs(x.start_time-c.end_time)<0.05 and x is not c),None)
        if not next_c: QMessageBox.warning(self,"Glue","No adjacent clip found immediately after the selected clip."); return
        c.source_out=next_c.source_out; c.duration_on_timeline=c.duration_on_timeline+next_c.duration_on_timeline
        self.tl.remove_clip(next_c)
        if c.id in self.tl.clip_items: self.tl.clip_items[c.id].update_geometry()
        self.statusBar().showMessage(f"Glued '{c.name}' — new duration {c.duration_on_timeline:.2f}s")

    def _snap_clips(self):
        """Snap all clips on each track to eliminate gaps"""
        for track in self.tl.tracks:
            if not track.clips:
                continue
            # Sort clips by start time
            track.clips.sort(key=lambda c: c.start_time)
            # Position clips sequentially with no gaps
            current_pos = 0.0
            for clip in track.clips:
                clip.start_time = current_pos
                current_pos += clip.duration_on_timeline
            # Redraw timeline
            if hasattr(self, 'tl'):
                self.tl._setup_scene()

    def _text(self):
        """Create text clip on TEXT track"""
        try:
            self._snapshot()
            # Get TEXT track
            text_track = next((t for t in self.tl.tracks if t.track_type == ClipType.TEXT), None)
            if not text_track:
                QMessageBox.warning(self, "Error", "TEXT track not found")
                return
            
            # Create clip with defaults — duration comes from the dialog
            ts = int(time.time() * 1000)
            text_clip = MediaClip(
                id=f"txt_{ts}", path=Path(""), name="Text",
                clip_type=ClipType.TEXT, duration=3600.0, fps=30.0,
                width=1920, height=1080, track_index=text_track.index,
                start_time=self.tl.current_time, source_in=0.0, source_out=3600.0,
                duration_on_timeline=5.0, text_content="Text",
                text_position=(50, 50), text_font_size=36,
                text_color="#FFFFFF", text_font="Arial"
            )
            
            # Open editor
            d = TextOverlayDialog(text_clip, self)
            if d.exec() != QDialog.DialogCode.Accepted:
                return
            
            # Update from editor — duration is user-specified
            dur = d.get_duration()
            text_clip.text_content = d.get_text() or "Text"
            text_clip.text_position = d.get_position()
            text_clip.text_font_size = d.get_font_size()
            text_clip.text_color = d.get_color()
            text_clip.text_font = d.get_font()
            text_clip.text_centered = d.get_centered()
            text_clip.duration_on_timeline = dur
            text_clip.source_out = dur
            
            # Add to timeline
            self.tl.add_clip(text_clip)
            self.tl.selected_clip = text_clip
            self._sel(text_clip)
            
            self.statusBar().showMessage(f"Text added: {text_clip.text_content}")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Text error: {str(e)}")
    def export_video(self):
        dlg=QDialog(self); dlg.setWindowTitle("Export"); dlg.setModal(True); dlg.resize(450,350)
        lay=QVBoxLayout(dlg)
        fl=QHBoxLayout(); fl.addWidget(QLabel("Output:")); oe=QLineEdit(); oe.setPlaceholderText("out.mp4"); fl.addWidget(oe)
        bb=QPushButton("Browse"); bb.clicked.connect(lambda: oe.setText(QFileDialog.getSaveFileName(self,"Save","","MP4 (*.mp4)")[0] or "")); fl.addWidget(bb); lay.addLayout(fl)
        sg=QGroupBox("Settings"); sl=QGridLayout(sg)
        sl.addWidget(QLabel("Resolution:"),0,0); rc=QComboBox()
        rc.addItems(["1920x1080 (HD)", "1280x720", "1080x1920 (Vertical/Reels)", "1440x2560 (TikTok Vertical)", "3840x2160 (4K)", "640x480"])
        sl.addWidget(rc,0,1)
        sl.addWidget(QLabel("FPS:"),1,0); fs=QSpinBox(); fs.setRange(1,60); fs.setValue(30); sl.addWidget(fs,1,1)
        sl.addWidget(QLabel("Quality (CRF 0-51)"),2,0); cs=QSpinBox(); cs.setRange(0,51); cs.setValue(23); cs.setToolTip("CRF = Constant Rate Factor. 0=lossless, 18=excellent, 23=default, 51=worst quality"); sl.addWidget(cs,2,1)
        crf_info=QLabel("CRF: 0=lossless/huge file  ·  18=excellent  ·  23=default (good balance)  ·  28=smaller file/lower quality  ·  51=worst")
        crf_info.setStyleSheet("color:#888;font-size:9px;"); crf_info.setWordWrap(True)
        sl.addWidget(crf_info,3,0,1,2)
        lay.addWidget(sg)
        pb=QProgressBar(); pb.setVisible(False); lay.addWidget(pb)
        st=QLabel(); lay.addWidget(st)
        btns=QDialogButtonBox(QDialogButtonBox.StandardButton.Ok|QDialogButtonBox.StandardButton.Cancel)
        btns.accepted.connect(lambda: self._start_exp(oe.text(), rc.currentText().split(" ")[0], fs.value(), cs.value(), pb, st, dlg))
        btns.rejected.connect(dlg.reject); lay.addWidget(btns)
        dlg.exec()
    def _start_exp(self, out, res, fps, crf, pb, st, dlg):
        if not out: QMessageBox.warning(self,"Export","Specify output path"); return
        if self.export_worker.isRunning(): QMessageBox.warning(self,"Export","Export already running"); return
        self.export_worker.output_path=out; self.export_worker.timeline=self.tl
        self.export_worker.resolution=res; self.export_worker.fps=fps; self.export_worker.crf=crf
        self.export_worker.preview_height=max(1,self.prg_mon.vid_lab.height())
        pb.setVisible(True); pb.setValue(0); st.setText("Starting…")
        # Disconnect any previous finished signal connections to avoid stacking
        try: self.export_worker.finished.disconnect()
        except: pass
        try: self.export_worker.progress.disconnect()
        except: pass
        try: self.export_worker.status.disconnect()
        except: pass
        self.export_worker.progress.connect(pb.setValue)
        self.export_worker.status.connect(st.setText)
        def _on_finished(success, msg):
            pb.setVisible(False); st.setText("")
            # Close the export dialog first, then show result
            try: dlg.accept()
            except: pass
            if success:
                QMessageBox.information(self,"Export Complete",msg)
            else:
                QMessageBox.critical(self,"Export Error",msg)
        self.export_worker.finished.connect(_on_finished)
        self.export_worker.start()
    def show_about(self):
        QMessageBox.about(self,"About",f"<h2 style='color:#fff;'>{APP_NAME}</h2><p style='color:#aaa;'>v{VERSION}</p><p style='color:#888;'>{ORG_NAME}</p><p style='color:#666;'>A simple video editor.</p><hr style='border-color:#333;'><p style='color:#555;font-size:11px;'>Built with PyQt6, OpenCV, FFmpeg</p>")
    def keyPressEvent(self,e):
        k=e.key()
        if k==Qt.Key.Key_Space:
            if self._tl_timer.isActive(): self._stop_tl()
            elif self.playback.playing and self._playing_src: self.playback.pause(); self.src_mon.pause()
            elif self._playing_src and not self.playback.playing: self._play_src()
            else: self._play_prg()
        elif k==Qt.Key.Key_L: self._play_prg()
        elif k==Qt.Key.Key_K:
            if self._tl_timer.isActive(): self._stop_tl()
            else: self.playback.pause(); self.src_mon.pause()
        elif k==Qt.Key.Key_J: t=max(0,self.tl.current_time-2.0); self.tl.set_current_time(t)
        elif k==Qt.Key.Key_Left:
            fps=self._tl_fps if self._tl_clips else max(1,self.playback.fps)
            self.tl.set_current_time(max(0,self.tl.current_time-1.0/fps))
        elif k==Qt.Key.Key_Right:
            fps=self._tl_fps if self._tl_clips else max(1,self.playback.fps)
            self.tl.set_current_time(self.tl.current_time+1.0/fps)
        elif k==Qt.Key.Key_I: self.src_mon._set_in()
        elif k==Qt.Key.Key_O: self.src_mon._set_out()
        elif k in (Qt.Key.Key_Delete,Qt.Key.Key_Backspace): self._snapshot(); self.tl.delete_selected()
        elif k==Qt.Key.Key_A and e.modifiers()&Qt.KeyboardModifier.ControlModifier: self.tl.select_all()
        elif k==Qt.Key.Key_Z and e.modifiers()&Qt.KeyboardModifier.ControlModifier: self._undo()
        elif k==Qt.Key.Key_Y and e.modifiers()&Qt.KeyboardModifier.ControlModifier: self._redo()
        elif k in (Qt.Key.Key_Plus,Qt.Key.Key_Equal) and e.modifiers()&Qt.KeyboardModifier.ControlModifier: self.tl.zoom_in()
        elif k==Qt.Key.Key_Minus and e.modifiers()&Qt.KeyboardModifier.ControlModifier: self.tl.zoom_out()
        elif k==Qt.Key.Key_0 and e.modifiers()&Qt.KeyboardModifier.ControlModifier: self._zoom_fit()
        elif k==Qt.Key.Key_E and e.modifiers()&Qt.KeyboardModifier.ControlModifier: self.export_video()
        elif k==Qt.Key.Key_S and e.modifiers()&Qt.KeyboardModifier.ControlModifier: self._save_project()
        elif k==Qt.Key.Key_T and e.modifiers()&Qt.KeyboardModifier.ControlModifier: self._text()
        elif k==Qt.Key.Key_K and e.modifiers()&Qt.KeyboardModifier.ControlModifier: self._split()
        elif k==Qt.Key.Key_J and e.modifiers()&Qt.KeyboardModifier.ControlModifier: self._glue()
        elif k==Qt.Key.Key_F9: self._insert()
        elif k==Qt.Key.Key_F10: self._overwrite()
        else: super().keyPressEvent(e)
    def _show_properties(self):
        """Show/raise the Properties floating dock (View menu / Ctrl+P)."""
        if hasattr(self,'_pp'):
            self._pp.show(); self._pp.raise_()
    def showEvent(self,e):
        super().showEvent(e)
        if getattr(self,'_state_restored',False): return
        self._state_restored=True
        settings=QSettings(ORG_NAME,APP_NAME)
        geom=settings.value("geometry")
        state=settings.value("windowState")
        # Block volume slider signals during restore — geometry changes can cause
        # spurious valueChanged emissions that restart audio players mid-playback.
        self.mv.blockSignals(True)
        if geom: self.restoreGeometry(geom)
        if state: self.restoreState(state)
        self.mv.blockSignals(False)
        if hasattr(self,'_pp') and self._pp.isFloating():
            pp_geom=settings.value("propertiesGeometry")
            if pp_geom:
                self._pp.restoreGeometry(pp_geom)
            else:
                prop_h=160; prop_w=240
                self._pp.resize(prop_w,prop_h)
                self._pp.move(max(0,self.x()+4), max(0,self.y()+self.height()-prop_h-80))
    def closeEvent(self,e):
        self._stop_tl(); _stop_all_audio(); self.playback.cleanup()
        if self.export_worker.isRunning(): self.export_worker.stop()
        settings=QSettings(ORG_NAME,APP_NAME)
        settings.setValue("geometry",self.saveGeometry())
        settings.setValue("windowState",self.saveState())
        if hasattr(self,'_pp'): settings.setValue("propertiesGeometry",self._pp.saveGeometry())
        e.accept()


def main():
    # Windows taskbar icon fix — must be set BEFORE QApplication is created.
    # This tells Windows this process has its own identity, so it shows the
    # app icon in the taskbar rather than a generic Python icon.
    if sys.platform == "win32":
        try:
            import ctypes
            myappid = "DeathsHeadSoftware.VideoOfDeath.1.0.41"
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(myappid)
        except Exception: pass

    app=QApplication(sys.argv)

    # Load icon from bundled location (PyInstaller _MEIPASS or script dir)
    def _icon_path(name):
        if hasattr(sys, "_MEIPASS"):
            p = os.path.join(sys._MEIPASS, name)
            if os.path.isfile(p): return p
        base = os.path.dirname(sys.executable if getattr(sys,"frozen",False)
                               else os.path.abspath(__file__))
        p = os.path.join(base, name)
        if os.path.isfile(p): return p
        return None

    ico = _icon_path("icon.ico") or _icon_path("icon.png")
    if ico:
        app_icon = QIcon(ico)
        app.setWindowIcon(app_icon)
    else:
        app_icon = None
    style = QStyleFactory.create("Fusion")
    if style:
        app.setStyle(style)
    pal=QPalette(); pal.setColor(QPalette.ColorRole.Window,QColor(30,30,30)); pal.setColor(QPalette.ColorRole.WindowText,QColor(255,255,255))
    pal.setColor(QPalette.ColorRole.Base,QColor(20,20,20)); pal.setColor(QPalette.ColorRole.AlternateBase,QColor(40,40,40))
    pal.setColor(QPalette.ColorRole.Text,QColor(255,255,255)); pal.setColor(QPalette.ColorRole.Button,QColor(50,50,50))
    pal.setColor(QPalette.ColorRole.ButtonText,QColor(255,255,255)); pal.setColor(QPalette.ColorRole.Highlight,QColor(42,130,218))
    app.setPalette(pal)
    splash=create_splash()
    if splash:
        splash.show()
        for msg in ["Starting...","Initializing FFmpeg...","Loading codecs...","Preparing timeline...","Ready!"]:
            splash.showMessage("\n\n\n\n\n\n\n"+msg, Qt.AlignmentFlag.AlignBottom|Qt.AlignmentFlag.AlignCenter, QColor(255,255,255))
            app.processEvents(); time.sleep(1.08)
        ed=VideoEditor(); 
        if app_icon: ed.setWindowIcon(app_icon)
        ed.show(); splash.finish(ed)
    else:
        ed=VideoEditor()
        if app_icon: ed.setWindowIcon(app_icon)
        ed.show()
    # Open .vod file passed as command-line argument (file association)
    vod=next((a for a in sys.argv[1:] if a.lower().endswith('.vod') and os.path.exists(a)),None)
    if vod:
        try: ed._open_project_path(vod)
        except Exception as ex: print(f'Could not open {vod}: {ex}')
    sys.exit(app.exec())

if __name__ == "__main__":
    main()