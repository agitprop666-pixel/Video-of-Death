================================================================
              VIDEO OF DEATH — User Manual
              Death's Head Software
              Version 1.0.41
================================================================

A non-linear video editor built around a media bin, dual monitors
(Source + Program), and a multi-track timeline. Renders via FFmpeg.


================================================================
1. THE WORKSPACE
================================================================

Window layout, top to bottom, left to right:

  Menu bar           File / Edit / View / Text / Audio / Help
  Toolbar            Split, Text, Insert, Overwrite, Zoom, Export
  Media Bin (left)   Imported source clips
  Source Monitor     Preview of the clip selected in the Bin
  Program Monitor    Preview of the timeline output
  Timeline (bottom)  Tracks where you arrange clips
  Status bar         Operation feedback

The timeline always has these tracks:

  Video 1     Top track. Holds video and image clips only.
  Audio 1     Linked audio from video clips lands here by default.
  Audio 2     For music, narration, sound effects.
  Text        Below Audio 2. Holds text overlays.

Each track header has a mute toggle and a volume slider (audio
tracks only).


================================================================
2. STARTING A PROJECT
================================================================

  File → New                        Ctrl+N
  File → Open Project...            Ctrl+O
  File → Save Project               Ctrl+S
  File → Close Project              (clears bin and timeline)

Projects save the timeline arrangement, in/out trims, fades,
text, and references to your source files. They do NOT embed
the media itself — keep your source files where the project
expects them.


================================================================
3. IMPORTING MEDIA
================================================================

Click "Import Media" in the Media Bin panel. Supported types:

  Video    .mp4, .mov, .avi, .mkv, .webm
  Audio    .mp3, .wav, .flac, .ogg, .m4a
  Image    .jpg, .png, .bmp, .tiff, .webp

Imported clips appear in the Bin with a type icon (🎬 video,
🎵 audio, 🖼️ image). Click any clip to load it into the Source
Monitor. Right-click for Remove or Info.


================================================================
4. THE SOURCE MONITOR
================================================================

Top of the panel: video preview.
Bottom: scrub bar with In/Out markers, then control buttons.

Buttons left to right:

  ■        Stop
  ▶ / ⏸    Play / Pause
  I        Mark In point at current playhead
  O        Mark Out point at current playhead
  ✕        Clear In and Out points
  F9 Ins   3-Point Insert into the timeline
  F10 OW   3-Point Overwrite into the timeline

In/Out workflow:
  1. Scrub or play to the moment you want as the start of the
     trimmed clip, click I.
  2. Scrub or play to the end point, click O.
  3. The In/Out marks are now displayed under the scrub bar.
  4. Use F9 (Insert) or F10 (Overwrite) to drop the trimmed
     region onto the timeline at the playhead.

If no In/Out is set, the whole source clip gets used.


================================================================
5. THE TIMELINE
================================================================

DROPPING CLIPS:

  Drag from the Bin onto the timeline at any time position. The
  app routes by clip type:

    Video clip    → Video 1 track. Its audio twin is auto-created
                    on Audio 1 and linked to the video clip. Both
                    move together when dragged.
    Audio clip    → Audio 1 (or whichever audio track you drop on)
    Image clip    → Video 1
    Text          → use Text menu, not drag-drop

  3-Point Insert/Overwrite (F9/F10) drops the source clip's
  trimmed In/Out region at the current Program-Monitor playhead.

NAVIGATING:

  Click anywhere on the timeline ruler to position the playhead.
  Use the Program Monitor's ▶ button to play from the playhead.

  Zoom In       Ctrl++   or  Ctrl+=
  Zoom Out      Ctrl+-
  Zoom to Fit   Ctrl+0   (fits the entire timeline edit)

SELECTING:

  Click a clip to select it (highlights).
  Ctrl+Click to add to the selection.
  Right-click anywhere on empty timeline area for the global
  context menu (Select All, Delete Selected, Zoom).
  Right-click on a clip for clip-specific actions: Split, Glue,
  Text Overlay, Mute, Delete.

MOVING AND TRIMMING:

  Drag a clip body to move it horizontally or to a different
  audio track. (Video clips stay on Video 1.)
  Drag a clip's left edge to trim its in-point.
  Drag a clip's right edge to trim its out-point.

EDITING:

  Split at Playhead   Ctrl+K     Cuts the clip under the playhead
                                 into two pieces. The right (B)
                                 half is auto-selected.
  Glue (Join) Clips   Ctrl+J     Merges the selected clip with
                                 the clip immediately following
                                 it on the same track.
  Delete              Delete     Removes selected clip(s).
  Undo / Redo         Ctrl+Z / Ctrl+Y   Up to 50 steps.


================================================================
6. TEXT OVERLAYS
================================================================

Text → Add Text...              Ctrl+T

Opens the Text Overlay editor. Set:
  - Text content (multi-line OK)
  - Font, size, color
  - Position (percentage of frame, X and Y) or Centered
  - Duration on timeline

The text clip lands on the TEXT track at the current playhead
and renders as an overlay on top of any video or image at that
moment.

To edit existing text: right-click the text clip on the timeline
and choose Text Overlay (or use the same Text menu while it's
selected — the editor reopens with its current values).


================================================================
7. AUDIO FADES (NEW IN 1.0.41)
================================================================

Fades are previewed live during timeline playback by rendering
a faded copy of the audio clip offline. The render uses the
exact same FFmpeg afade filter the export pipeline uses, so
preview and final export are sample-identical.

WORKFLOW:

  1. Click an audio clip on the timeline to select it.
  2. Audio → Fade In        Set fade-in duration in seconds.
     Audio → Fade Out       Set fade-out duration in seconds.
  3. A short progress dialog appears while ffmpeg renders the
     faded preview. For typical clips this is a few seconds.
  4. Press Play in the Program Monitor to hear the fade.

Fade ramps are drawn as translucent triangles on the clip on
the timeline so you can see them at a glance.

To remove fades:
  Audio → Remove Fades

If something goes wrong (you trim the clip after setting fades,
the original render failed silently, etc):
  Audio → Render Fade Preview         Re-renders the selected clip
  Audio → Render All Fade Previews    Re-renders every clip with fades

NOTES:

  - For VIDEO clips, fades apply to the LINKED audio twin on
    Audio 1, not the video clip itself.
  - Cached previews live in the system temp folder under
    "vod_audio_render". The cache is wiped automatically on
    every app launch so you never play a stale render.
  - Fade values are saved with the project and re-applied on
    Open, but the cached audio is not — the first time you
    play a project after opening, the rendered preview is
    regenerated on demand. Use Render All Fade Previews after
    opening to do them all up front.


================================================================
8. VOLUME CONTROL
================================================================

Three layers of volume, multiplied together:

  Master volume    Slider in the Program Monitor's control bar,
                   range 0–150%. Affects everything.
  Track volume     Slider in each audio track's header. Per-track.
  Clip volume      Per-clip property (currently exposed via the
                   clip's right-click → Properties dialog).

Mute:
  - Right-click clip → Mute toggles a single clip.
  - Click the speaker icon in a track header to mute the track.


================================================================
9. EXPORTING
================================================================

  File → Export Video...          Ctrl+E
  Or click the blue 🎥 Export button in the toolbar.

The Export dialog asks for:

  Output path        Pick a destination .mp4 with Browse.
  Resolution         1920x1080 (HD), 1280x720, 1080x1920
                     (Vertical/Reels), 1440x2560 (TikTok),
                     3840x2160 (4K), 640x480.
  FPS                1–60. Default 30.
  CRF                0–51 quality factor. Lower = better.
                       0  = lossless / huge file
                      18  = excellent
                      23  = default, good balance
                      28  = smaller, lower quality
                      51  = worst

Export runs in the background. A progress bar updates while
ffmpeg works. When done, you get a confirmation dialog or an
error message with the ffmpeg tail.

Export pipeline highlights:
  - Video clips, image clips, and text overlays all render
    through one ffmpeg filter graph.
  - Audio fades use the afade filter (same as the live preview).
  - Multiple audio tracks are mixed via amix (no normalization,
    so set track volumes to taste before exporting).


================================================================
10. KEYBOARD SHORTCUT REFERENCE
================================================================

  FILE
    Ctrl+N         New project
    Ctrl+O         Open project
    Ctrl+S         Save project
    Ctrl+E         Export
    Ctrl+Q         Exit

  EDIT
    Ctrl+Z         Undo
    Ctrl+Y         Redo
    Delete         Delete selected clip(s)
    Ctrl+K         Split at playhead
    Ctrl+J         Glue (join) adjacent clips
    F9             3-Point Insert
    F10            3-Point Overwrite

  VIEW
    Ctrl+ +        Zoom In
    Ctrl+ -        Zoom Out
    Ctrl+0         Zoom to Fit
    Ctrl+P         Properties of selected clip

  TEXT
    Ctrl+T         Add text overlay


================================================================
11. TROUBLESHOOTING
================================================================

NO AUDIO / NO VIDEO ON PLAYBACK
  - Check that the track isn't muted (track header speaker icon).
  - Check master volume in the Program Monitor.
  - Make sure the source file still exists at its original path.
    If a project was moved or media re-organized, the path
    references will be broken.

FADE DOESN'T MATCH WHAT YOU EXPECT
  - Audio → Render Fade Preview to force a fresh render.
  - If you trimmed the clip after setting fades, the cached
    preview is stale. Re-render.
  - Compare the rendered file directly: it lives in the system
    temp folder under "vod_audio_render" as
    "clip_<hash>.wav". Open it in any audio player to verify.

EXPORT FAILS
  - The error dialog shows the last ~20 lines of ffmpeg output.
  - Most common cause: missing codec for an unusual source file
    or invalid output path (no write permission, missing folder).
  - Make sure ffmpeg.exe is alongside the script (or bundled in
    the PyInstaller build).

PLAYHEAD AND AUDIO FALL OUT OF SYNC
  - Fixed in 1.0.41 — the timeline clock is now wall-clock
    anchored. If you see drift on extremely long timelines,
    seek to a fresh position to re-anchor.

APP LAUNCHED BUT NO WINDOW SOUND
  - Some Windows audio device configurations conflict with
    ffplay. Confirm ffplay.exe is bundled. Try a different
    output device in Windows audio settings.


================================================================
12. FILE LOCATIONS
================================================================

  Project files       Wherever you save them. .vod extension.
  Media references    Stored as absolute paths in the project.
  Fade preview cache  <system temp>\vod_audio_render\
                      Wiped on every app start.
  ffmpeg / ffplay     Bundled alongside the executable, or
                      found on PATH if not bundled.

================================================================

                — Death's Head Software —
                  www.deathsheadsoftware.com

================================================================
